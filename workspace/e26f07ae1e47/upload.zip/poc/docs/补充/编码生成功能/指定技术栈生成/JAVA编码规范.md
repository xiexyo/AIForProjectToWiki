# Java 编码规范
版本: 1.0

## 1. 命名规范

### 1.1 通用命名原则
- 名称应具有描述性，一目了然
- 避免使用缩写，除非是公认的标准（如 URL, HTTP, ID）
- 同一概念在不同场景保持一致

### 1.2 各类命名规范

| 元素类型       | 命名风格     | 命名示例                    |
|----------------|--------------|-----------------------------|
| 类/接口        | PascalCase   | UserService, Runnable       |
| 方法           | camelCase    | getUserById, calculateTotal  |
| 变量           | camelCase    | userName, orderList         |
| 常量           | UPPER_SNAKE  | MAX_RETRY_COUNT, API_URL    |
| 枚举值         | UPPER_SNAKE  | SUCCESS, NOT_FOUND          |
| 包名           | 全小写       | com.company.project         |
| 泛型参数       | 单大写字母   | T, E, K, V                  |

### 1.3 命名示例

```java
// ✅ 正确示例
public class UserAccountService {
    private static final int MAX_LOGIN_ATTEMPTS = 5;
    private UserRepository userRepository;
    private Map<String, Session> activeSessions;
    
    public Optional<User> findUserById(Long id) { }
    public boolean validateUserCredentials(String username, String password) { }
    public void logout(String sessionId) { }
}

// ❌ 错误示例
public class userAccount {
    private int maxLoginAttempts;  // 变量用camelCase
    private UserRepository ur;     // 缩写不清晰
    public User getUserByID(Long ID);  // ID应为Id
}
```

---

## 2. 代码格式规范

### 2.1 缩进与空白

```java
// 缩进：4个空格（禁用Tab，配置IDE转换）
// 行长度：≤120字符

public class Example {
    
    // 成员变量与普通方法之间空一行
    private String name;
    private int age;
    
    // 方法之间空两行
    public void methodOne() {
        if (condition) {  // 条件语句空格
            doSomething();
        }
    }
    
    public void methodTwo() {
        // 方法体
    }
}
```

### 2.2 大括号风格（1TBS）

```java
// 括号位置：左括号同行，右括号独立一行
public class MyClass {
    
    public void myMethod() {
        if (x > 0) {
            // 处理逻辑
        } else if (x < 0) {
            // 处理逻辑
        } else {
            // 处理逻辑
        }
    }
    
    // 单独的大括号也要缩进
    public void emptyMethod() {
    }
}

// Switch语句
switch (status) {
    case SUCCESS:
        handleSuccess();
        break;
    case FAIL:
        handleFail();
        break;
    default:
        handleDefault();
        break;
}
```

### 2.3 导入语句

```java
// 顺序：java → javax → 第三方 → 本项目
// 组间空行，同组按字母顺序

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import com.company.project.service.UserService;
import com.company.project.model.User;
```

### 2.4 注解位置

```java
// 类注解
@Entity
@Table(name = "users")
public class User {
    
    // 字段注解同行
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 50)
    private String name;
    
    // 方法注解同行
    @Autowired
    public UserService userService;
    
    // 多个注解分行写
    @SuppressWarnings("unchecked")
    @Deprecated
    public void oldMethod() {
        // ...
    }
}
```

---

## 3. 注释规范

### 3.1 注释类型

```java
/**
 * 商品实体类
 * 用于表示系统中所有商品信息
 *
 * @author zhangsan
 * @version 2.0
 * @since 2024-01-01
 */
public class Product {
    
    /**
     * 商品名称
     * 最长50个字符，不能为空
     */
    private String name;
    
    // 单行注释：描述紧随其后的代码
    // 计算订单总金额
    private BigDecimal totalAmount;
    
    /**
     * 获取商品详情
     * 
     * @param productId 商品ID
     * @return 商品详情DTO
     * @throws ProductNotFoundException 当商品不存在时抛出
     */
    public ProductDetailDTO getProductDetail(Long productId) {
        // TODO: 添加缓存逻辑
        // FIXME: 高并发下可能存在问题
        // HACK: 临时解决方案，需要重构
        return productMapper.selectById(productId);
    }
}
```

### 3.2 Javadoc标签使用

```java
/**
 * 用户注册
 *
 * @param username 用户名 (4-20位字母数字)
 * @param email    邮箱地址
 * @param password 密码 (8位以上，含大小写和数字)
 * @return 注册结果
 * @throws IllegalArgumentException 参数验证失败
 * @throws UserAlreadyExistsException 用户名已存在
 * 
 * @see #login(String, String)
 * @see UserService#updateUserInfo(User)
 */
public RegisterResult register(String username, String email, String password) {
    // 实现
}
```

---

## 4. 类与方法设计

### 4.1 类设计原则

```java
// ✅ 单一职责原则
public class UserValidator {
    public boolean isValidUsername(String username) { }
    public boolean isValidEmail(String email) { }
}

// ❌ 职责过多
public class UserHelper {
    public void validate() { }
    public void save() { }
    public void sendEmail() { }  // 不应属于此类
}

// ✅ 优先使用组合而非继承
public class UserService {
    private EmailService emailService;
    private SmsService smsService;
}

// ✅ 使用不可变类
public final class Point {
    private final int x;
    private final int y;
    
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    // 无setter方法
}
```

### 4.2 方法设计原则

```java
// ✅ 方法应该简洁（建议≤50行）
public BigDecimal calculateOrderTotal(Order order) {
    return order.getItems().stream()
        .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
        .reduce(BigDecimal.ZERO, BigDecimal::add);
}

// ✅ 参数校验
public void createUser(String username, String email) {
    if (username == null || username.trim().isEmpty()) {
        throw new IllegalArgumentException("用户名不能为空");
    }
    if (email == null || !isValidEmail(email)) {
        throw new IllegalArgumentException("邮箱格式不正确");
    }
    // 业务逻辑
}

// ✅ 返回空集合而非null
public List<Order> getUserOrders(Long userId) {
    if (userId == null) {
        return Collections.emptyList();  // 不要返回null
    }
    return orderRepository.findByUserId(userId);
}
```

---

## 5. 异常处理

### 5.1 异常使用规范

```java
// ✅ 自定义异常
public class BusinessException extends RuntimeException {
    private final String code;
    
    public BusinessException(String code, String message) {
        super(message);
        this.code = code;
    }
    
    public BusinessException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }
}

// ✅ 异常处理
public User getUserById(Long id) {
    try {
        return userRepository.findById(id)
            .orElseThrow(() -> new BusinessException("USER_NOT_FOUND", "用户不存在"));
    } catch (DataAccessException e) {
        log.error("数据库查询失败", e);
        throw new BusinessException("DB_ERROR", "系统繁忙，请稍后重试", e);
    }
}

// ✅ 资源关闭 - try-with-resources
public String readFileContent(String path) {
    try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
        return reader.lines().collect(Collectors.joining("\n"));
    } catch (IOException e) {
        log.error("读取文件失败: {}", path, e);
        throw new BusinessException("FILE_READ_ERROR", "文件读取失败");
    }
}
```

---

## 6. 常用代码模板

### 6.1 DTO类模板

```java
/**
 * 用户登录请求DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequest {
    
    @NotBlank(message = "用户名不能为空")
    @Size(min = 4, max = 20, message = "用户名长度4-20位")
    private String username;
    
    @NotBlank(message = "密码不能为空")
    private String password;
    
    private Boolean rememberMe;
}
```

### 6.2 Service模板

```java
/**
 * 用户管理服务
 */
@Service
@RequiredArgsConstructor
public class UserService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    
    /**
     * 创建新用户
     */
    @Transactional
    public User createUser(CreateUserRequest request) {
        // 1. 参数校验
        validateCreateRequest(request);
        
        // 2. 检查重复
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new BusinessException("USERNAME_EXISTS", "用户名已存在");
        }
        
        // 3. 构建实体
        User user = User.builder()
            .username(request.getUsername())
            .password(passwordEncoder.encode(request.getPassword()))
            .email(request.getEmail())
            .status(UserStatus.ACTIVE)
            .createTime(LocalDateTime.now())
            .build();
        
        // 4. 保存
        User savedUser = userRepository.save(user);
        
        // 5. 发送欢迎邮件（异步）
        emailService.sendWelcomeEmail(savedUser);
        
        return savedUser;
    }
}
```

### 6.3 Controller模板

```java
/**
 * 用户管理接口
 */
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    
    private final UserService userService;
    
    /**
     * 获取用户详情
     */
    @GetMapping("/{id}")
    public Result<UserDetailVO> getUserById(@PathVariable Long id) {
        return Result.success(userService.getUserById(id));
    }
    
    /**
     * 创建用户
     */
    @PostMapping
    public Result<User> createUser(@Valid @RequestBody CreateUserRequest request) {
        return Result.success(userService.createUser(request));
    }
    
    /**
     * 统一异常处理
     */
    @ExceptionHandler(BusinessException.class)
    public Result<Void> handleBusinessException(BusinessException e) {
        log.warn("业务异常: {}", e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    }
}
```

---

## 7. 最佳实践清单

### ✅ 推荐做法
```
1. 使用Lombok减少样板代码
2. 使用Stream API处理集合
3. 使用Optional处理可能为null的值
4. 使用枚举替代常量类
5. 使用lambda表达式替代匿名类
6. 使用构建者模式创建复杂对象
7. 集合类型声明使用接口：List, Map, Set
8. 字符串比较常量放前面
9. 使用Apache Commons Lang工具类
10. 使用slf4j + logback日志框架
```

### ❌ 避免做法
```
1. 避免使用HashMap/HashSet声明集合类型
2. 避免在循环中try-catch
3. 避免捕获Exception或Throwable
4. 避免使用assert进行参数校验
5. 避免在finally块中返回或抛出异常
6. 避免使用Date类，使用java.time包
7. 避免使用+拼接字符串，使用StringBuilder
8. 避免使用Float/Double做精确计算，使用BigDecimal
9. 避免在构造函数中调用可被重写的方法
10. 避免在Serializable类中手动维护serialVersionUID
```

---

## 8. Git提交信息规范

```
<type>(<scope>): <subject>

[body]

[footer]

类型：
- feat: 新功能
- fix: 修复bug
- docs: 文档变更
- style: 代码格式（不影响功能）
- refactor: 重构
- perf: 性能优化
- test: 测试相关
- chore: 构建/工具

示例：
feat(user): 添加用户注册功能

- 添加用户名唯一性校验
- 添加密码强度验证
- 集成短信验证码服务

Closes #123
```
