# VBA 编码规范
版本: 1.0 |

## 1. 命名规范

### 1.1 命名约定总览

| 类型               | 前缀        | 示例                        |
|--------------------|-------------|-----------------------------|
| 窗体 (Form)        | frm         | frmUserLogin, frmMain       |
| 报表 (Report)      | rpt         | rptSalesSummary             |
| 模块 (Module)      | mod         | modDatabase, modUtilities   |
| 类模块 (Class)     | cls         | clsUser, clsOrder           |
| 公共变量           | g_          | g_CurrentUser, g_DBConn     |
| 模块级变量         | m_          | m_RecordSet, m_Counter      |
| 函数/子过程        | 动宾短语    | GetUserById, ProcessOrder   |
| 布尔变量           | is/has/can  | isActive, hasPermission     |
| 集合对象           | col         | colUsers, colOrders         |
| 对象变量           | obj         | objExcel, objWord           |
| 字符串变量         | str         | strName, strErrorMsg        |
| 整数变量           | int/lng     | intCount, lngTotal          |
| 日期变量           | dt/dte      | dtCreate, dteStart          |
| 布尔变量           | bln         | blnFound, blnIsValid        |
| 单精度浮点         | sng         | sngPrice                    |
| 双精度浮点         | dbl         | dblAmount, dblTaxRate       |
| 货币变量           | cur         | curTotal                    |
| 字节数组           | abyt/b()    | abytData, bBuffer()         |

### 1.2 详细命名示例

```vba
' ============ 变量声明 ============

' 模块级变量
Private m_Conn As ADODB.Connection
Private m_Rs As ADODB.Recordset
Private m_CurrentUserID As Long
Private m_blnIsConnected As Boolean

' 公共变量
Public g_AppPath As String
Public g_DBServer As String
Public g_CurrentUser As clsUser

' ============ 过程命名 ============

' 公共过程（动宾结构）
Public Sub GetUserById(lngUserID As Long)
Public Function ValidateLogin(strUsername As String, strPassword As String) As Boolean
Public Sub ProcessOrder(lngOrderID As Long)
Public Sub ExportToExcel(objWorksheet As Worksheet)

' 私有过程
Private Sub InitializeConnection()
Private Sub CleanupResources()
Private Sub LogError(objErr As ErrObject)

' ============ 类模块命名 ============

' 类名：cls + 业务名词
' clsUser
' clsOrder
' clsReportGenerator

' 类属性/方法命名
Public Property Get UserID() As Long
Public Property Let UserID(ByVal Value As Long)
Public Function GetOrders() As Collection
Public Sub Save()
Public Sub Delete()
```

---

## 2. 代码格式规范

### 2.1 缩进与空白

```vba
' ============ 缩进：4个空格 ============

Public Sub ProcessUserData(lngUserID As Long)
    
    Dim rs As ADODB.Recordset
    Dim strSQL As String
    Dim blnResult As Boolean
    
    ' 初始化
    Set rs = New ADODB.Recordset
    blnResult = False
    
    ' 业务逻辑
    If lngUserID <= 0 Then
        Exit Sub
    End If
    
    strSQL = "SELECT * FROM Users WHERE UserID = " & lngUserID
    
    Set rs = m_Conn.Execute(strSQL)
    
    If Not rs.EOF Then
        blnResult = True
    End If
    
    ' 清理
    rs.Close
    Set rs = Nothing
    
End Sub


' ============ 空行使用 ============

' 模块级声明之间空一行
Option Explicit

Private m_Conn As ADODB.Connection
Private m_Rs As ADODB.Recordset

Private Const MIN_VALUE As Long = 0
Private Const MAX_VALUE As Long = 100

' 过程之间空两行
Public Sub ProcedureOne()
End Sub


Public Sub ProcedureTwo()
End Sub


' 过程内部逻辑块之间空一行
Public Sub ProcessData()
    Dim intCount As Integer
    
    ' 第一步：获取数据
    intCount = GetRecordCount()
    
    If intCount = 0 Then
        Exit Sub
    End If
    
    ' 第二步：处理数据
    intCount = intCount + 1
    
    ' 第三步：保存结果
    SaveResult intCount
    
End Sub
```

### 2.2 代码行长度与换行

```vba
' ✅ 单行语句避免过长
' 如果必须换行，使用行继续符 _
strSQL = "SELECT u.UserID, u.UserName, u.Email, " & _
         "       o.OrderCount, o.TotalAmount " & _
         "FROM Users u " & _
         "LEFT JOIN Orders o ON u.UserID = o.UserID " & _
         "WHERE u.IsActive = True"


' ✅ 参数换行对齐
Public Sub CreateReport(strReportName As String, _
                        strDateFrom As String, _
                        strDateTo As String, _
                        Optional blnShowDialog As Boolean = False)
    ' 过程实现
End Sub


' ✅ 复杂条件换行
If lngUserID > 0 And strUserName <> "" And _
   IsDate(dtBirthDate) And blnIsValid Then
    ' 处理逻辑
End If
```

### 2.3 注释规范

```vba
' ============ 模块头部注释 ============
'==============================================================
' 模块名称：modUserManagement
' 模块描述：用户管理相关功能
' 创建日期：2024-01-01
' 创建者：张三
' 修改历史：
'   2024-01-15 李四 - 添加批量删除功能
'==============================================================

Option Explicit
Option Compare Text


' ============ 过程/函数注释 ============

'--------------------------------------------------------------
' 过程名称：GetUserByID
' 功能描述：根据用户ID获取用户信息
' 参数说明：
'   lngUserID - 用户ID
' 返回值：clsUser对象，失败返回Nothing
'--------------------------------------------------------------
Public Function GetUserByID(lngUserID As Long) As clsUser
    
    On Error GoTo ErrorHandler
    
    Dim objUser As clsUser
    Dim rs As ADODB.Recordset
    
    Set objUser = New clsUser
    Set rs = New ADODB.Recordset
    
    rs.Open "SELECT * FROM Users WHERE UserID = " & lngUserID, _
            m_Conn, adOpenForwardOnly, adLockReadOnly
    
    If Not rs.EOF Then
        objUser.UserID = rs("UserID")
        objUser.UserName = rs("UserName")
        objUser.Email = rs("Email")
        Set GetUserByID = objUser
    Else
        Set GetUserByID = Nothing
    End If
    
    rs.Close
    Set rs = Nothing
    Set objUser = Nothing
    
    Exit Function
    
ErrorHandler:
    Call LogError(Err)
    Set GetUserByID = Nothing
    
End Function


' ============ 行内注释 ============
lngCount = lngCount + 1  ' 计数器加1
strSQL = "DELETE FROM Orders"  ' 清理过期订单
```

---

## 3. 变量与数据类型

### 3.1 变量声明规范

```vba
' ============ 必须使用Option Explicit ============
Option Explicit

' ============ 变量声明位置：模块顶部或过程开头 ============

' ============ 推荐：逐一声明变量 ============
Dim strUserName As String
Dim lngUserID As Long
Dim dtBirthDate As Date
Dim blnIsActive As Boolean

' ============ 避免：在一行声明多个变量 ============
' ❌ 错误：逗号分隔的声明可能导致类型混淆
Dim strName, strAddress, strPhone As String  ' 只有strPhone是String，其他是Variant
Dim intA, intB, intC As Integer  ' 只有intC是Integer

' ✅ 正确：每个变量单独声明
Dim strName As String
Dim strAddress As String
Dim strPhone As String


' ============ 常用数据类型 ============

' 数值类型
Dim bytAge As Byte          ' 0-255
Dim intCount As Integer     ' -32768 到 32767
Dim lngID As Long           ' -2147483648 到 2147483647
Dim sngPrice As Single      ' 单精度浮点
Dim dblAmount As Double     ' 双精度浮点
Dim curTotal As Currency    ' 货币类型（4位小数）

' 字符串
Dim strName As String * 50  ' 固定长度
Dim strMessage As String    ' 可变长度

' 日期时间
Dim dtCreate As Date
Dim dtNow As Date

' 布尔
Dim blnIsValid As Boolean

' 对象
Dim objConn As ADODB.Connection
Dim objRs As ADODB.Recordset
Dim objExcel As Excel.Application
Dim objWS As Excel.Worksheet
```

### 3.2 常量定义

```vba
' ============ 模块级常量 ============
Private Const MODULE_NAME As String = "modUser"

' 业务常量
Private Const STATUS_ACTIVE As Integer = 1
Private Const STATUS_INACTIVE As Integer = 0
Private Const MAX_RETRY_COUNT As Integer = 3
Private Const DEFAULT_PAGE_SIZE As Integer = 20

' 数据库常量
Private Const CONNECTION_TIMEOUT As Integer = 30
Private Const COMMAND_TIMEOUT As Integer = 60

' 公共常量（在标准模块中定义）
Public Const APP_VERSION As String = "1.0.0"
Public Const APP_NAME As String = "用户管理系统"

' 枚举类型
Public Enum UserStatus
    usUnknown = 0
    usActive = 1
    usInactive = 2
    usBanned = 3
End Enum

Public Enum OrderStatus
    osPending = 1
    osConfirmed = 2
    osShipped = 3
    osCompleted = 4
    osCancelled = 5
End Enum
```

---

## 4. 过程与函数

### 4.1 过程设计原则

```vba
' ============ 子过程 ============

' ✅ 标准子过程
Public Sub InitializeApp()
    On Error GoTo ErrorHandler
    
    ' 初始化数据库连接
    Call InitDatabase
    
    ' 加载配置
    Call LoadConfiguration
    
    ' 显示主窗体
    frmMain.Show
    
    Exit Sub
    
ErrorHandler:
    Call HandleError(Err)
    
End Sub


' ✅ 带参数验证的子过程
Public Sub SaveUser(objUser As clsUser)
    
    ' 参数验证
    If objUser Is Nothing Then
        Err.Raise vbObjectError + 1001, "SaveUser", "用户对象不能为空"
        Exit Sub
    End If
    
    If objUser.UserID <= 0 Then
        Err.Raise vbObjectError + 1002, "SaveUser", "无效的用户ID"
        Exit Sub
    End If
    
    ' 保存逻辑
    Call DoSaveUser objUser
    
End Sub


' ============ 函数 ============

' ✅ 返回布尔值
Public Function IsUserExists(lngUserID As Long) As Boolean
    
    On Error Resume Next
    IsUserExists = False
    
    Dim rs As ADODB.Recordset
    Set rs = m_Conn.Execute("SELECT 1 FROM Users WHERE UserID = " & lngUserID)
    
    If Not rs Is Nothing Then
        IsUserExists = Not rs.EOF
        rs.Close
    End If
    
    Set rs = Nothing
    
End Function


' ✅ 返回记录集
Public Function GetAllUsers() As ADODB.Recordset
    
    On Error GoTo ErrorHandler
    
    Dim rs As ADODB.Recordset
    Set rs = New ADODB.Recordset
    
    rs.Open "SELECT * FROM Users ORDER BY CreateTime DESC", _
            m_Conn, adOpenStatic, adLockReadOnly
    
    Set GetAllUsers = rs
    
    Exit Function
    
ErrorHandler:
    Set GetAllUsers = Nothing
    Call LogError Err
    
End Function


' ✅ 返回复杂类型（使用Type或类）
Public Type UserInfo
    UserID As Long
    UserName As String
    Email As String
    OrderCount As Long
    TotalAmount As Currency
End Type

Public Function GetUserSummary(lngUserID As Long) As UserInfo
    
    Dim udtInfo As UserInfo
    Dim rs As ADODB.Recordset
    
    Set rs = m_Conn.Execute("SELECT * FROM V_UserSummary WHERE UserID = " & lngUserID)
    
    If Not rs.EOF Then
        udtInfo.UserID = rs("UserID")
        udtInfo.UserName = rs("UserName")
        udtInfo.Email = rs("Email")
        udtInfo.OrderCount = rs("OrderCount")
        udtInfo.TotalAmount = rs("TotalAmount")
    End If
    
    GetUserSummary = udtInfo
    
End Function
```

### 4.2 参数传递

```vba
' ============ ByRef vs ByVal ============

' 默认是ByRef，VBA中建议显式声明

' ✅ 简单类型使用ByVal（防止意外修改）
Public Function CalculateTax(ByVal curAmount As Currency, _
                              ByVal dblRate As Double) As Currency
    CalculateTax = curAmount * dblRate
End Function


' ✅ 对象默认ByRef（对象本身就是引用）
Public Sub ProcessUser(objUser As clsUser)  ' 默认ByRef
    objUser.UserName = "新名称"
End Sub


' ✅ 可选参数
Public Function GetOrderTotal(ByVal lngOrderID As Long, _
                              Optional ByVal blnIncludeTax As Boolean = True) As Currency
    ' 实现
End Function


' ✅ 参数数组
Public Function SumValues(ParamArray Values()) As Double
    
    Dim vntValue As Variant
    Dim dblSum As Double
    
    For Each vntValue In Values
        dblSum = dblSum + CDbl(vntValue)
    Next vntValue
    
    SumValues = dblSum
    
End Function

' 调用：dblTotal = SumValues(10, 20, 30, 40)
```

---

## 5. 错误处理

### 5.1 错误处理模式

```vba
' ============ 过程级错误处理 ============

Public Sub MyProcedure()
    
    On Error GoTo ErrorHandler
    
    ' 主逻辑
    Call StepOne
    Call StepTwo
    Call StepThree
    
    Exit Sub
    
ErrorHandler:
    Call HandleError(Err, "MyProcedure")
    
End Sub


' ============ 函数级错误处理 ============

Public Function MyFunction(lngID As Long) As Boolean
    
    On Error GoTo ErrorHandler
    
    MyFunction = False
    
    ' 主逻辑
    Dim blnResult As Boolean
    blnResult = DoSomething(lngID)
    MyFunction = blnResult
    
    Exit Function
    
ErrorHandler:
    Call LogError(Err, "MyFunction")
    MyFunction = False
    
End Function


' ============ 忽略特定错误 ============

Public Sub SafeDelete()
    
    On Error Resume Next  ' 忽略运行时错误，继续执行
    
    m_Rs.Delete
    m_Rs.MoveNext
    
    On Error GoTo 0  ' 恢复默认错误处理
    
    If Err.Number <> 0 Then
        Call LogError(Err)
        Err.Clear
    End If
    
End Sub


' ============ 统一错误处理 ============

Private Sub HandleError(objErr As ErrObject, Optional strProcedure As String = "")
    
    Dim strMessage As String
    
    strMessage = "错误编号: " & objErr.Number & vbCrLf & _
                 "描述: " & objErr.Description & vbCrLf & _
                 "过程: " & strProcedure & vbCrLf & _
                 "来源: " & objErr.Source
    
    ' 记录日志
    Call WriteErrorLog(strMessage)
    
    ' 显示错误（调试模式）
    #If DebugMode Then
        MsgBox strMessage, vbCritical + vbOKOnly, "系统错误"
    #End If
    
End Sub
```

---

## 6. 数据库操作

### 6.1 ADO操作模板

```vba
' ============ 连接管理 ============

Private m_Conn As ADODB.Connection

Private Function GetConnection() As ADODB.Connection
    
    On Error GoTo ErrorHandler
    
    If m_Conn Is Nothing Then
        Set m_Conn = New ADODB.Connection
        m_Conn.ConnectionString = "Provider=SQLOLEDB.1;" & _
                                   "Data Source=localhost;" & _
                                   "Initial Catalog=MyDatabase;" & _
                                   "User ID=sa;" & _
                                   "Password=p@ssw0rd"
        m_Conn.ConnectionTimeout = 30
        m_Conn.CursorLocation = adUseClient
        m_Conn.Open
    End If
    
    Set GetConnection = m_Conn
    
    Exit Function
    
ErrorHandler:
    Set GetConnection = Nothing
    Call LogError(Err, "GetConnection")
    
End Function


Public Sub CloseConnection()
    
    On Error Resume Next
    
    If Not m_Conn Is Nothing Then
        If m_Conn.State = adStateOpen Then
            m_Conn.Close
        End If
        Set m_Conn = Nothing
    End If
    
End Sub


' ============ 执行查询 ============

Public Function ExecuteQuery(strSQL As String) As ADODB.Recordset
    
    On Error GoTo ErrorHandler
    
    Dim rs As ADODB.Recordset
    Set rs = New ADODB.Recordset
    
    Set rs = m_Conn.Execute(strSQL)
    
    Set ExecuteQuery = rs
    
    Exit Function
    
ErrorHandler:
    Set ExecuteQuery = Nothing
    Call LogError(Err, "ExecuteQuery")
    
End Function


' ============ 事务处理 ============

Public Sub TransferAmount(lngFromAccount As Long, _
                          lngToAccount As Long, _
                          curAmount As Currency)
    
    On Error GoTo ErrorHandler
    
    m_Conn.BeginTrans
    
    ' 扣除转出账户
    m_Conn.Execute "UPDATE Accounts SET Balance = Balance - " & curAmount & _
                   " WHERE AccountID = " & lngFromAccount
    
    ' 增加转入账户
    m_Conn.Execute "UPDATE Accounts SET Balance = Balance + " & curAmount & _
                   " WHERE AccountID = " & lngToAccount
    
    ' 记录转账日志
    Call LogTransfer lngFromAccount, lngToAccount, curAmount
    
    m_Conn.CommitTrans
    
    Exit Sub
    
ErrorHandler:
    m_Conn.RollbackTrans
    Call LogError(Err, "TransferAmount")
    
End Sub
```

---

## 7. Excel/Outlook操作

### 7.1 Excel操作模板

```vba
' ============ Excel操作基础 ============

Public Sub ExportToExcel()
    
    On Error GoTo ErrorHandler
    
    Dim objExcel As Excel.Application
    Dim objWorkbook As Excel.Workbook
    Dim objWorksheet As Excel.Worksheet
    Dim rs As ADODB.Recordset
    Dim lngRow As Long
    
    ' 创建Excel应用
    Set objExcel = New Excel.Application
    objExcel.Visible = True
    objExcel.DisplayAlerts = False
    
    ' 创建工作簿
    Set objWorkbook = objExcel.Workbooks.Add
    Set objWorksheet = objWorkbook.Worksheets(1)
    objWorksheet.Name = "用户报表"
    
    ' 写入表头
    objWorksheet.Cells(1, 1) = "用户ID"
    objWorksheet.Cells(1, 2) = "用户名"
    objWorksheet.Cells(1, 3) = "邮箱"
    objWorksheet.Cells(1, 4) = "注册日期"
    
    ' 格式化表头
    objWorksheet.Range("A1:D1").Font.Bold = True
    objWorksheet.Range("A1:D1").Interior.Color = RGB(200, 200, 200)
    
    ' 获取数据
    Set rs = GetAllUsers
    
    ' 写入数据
    lngRow = 2
    Do While Not rs.EOF
        objWorksheet.Cells(lngRow, 1) = rs("UserID")
        objWorksheet.Cells(lngRow, 2) = rs("UserName")
        objWorksheet.Cells(lngRow, 3) = rs("Email")
        objWorksheet.Cells(lngRow, 4) = rs("CreateTime")
        lngRow = lngRow + 1
        rs.MoveNext
    Loop
    
    ' 自动调整列宽
    objWorksheet.Columns("A:D").AutoFit
    
    ' 保存文件
    objWorkbook.SaveAs "C:\Reports\Users_" & Format(Now, "yyyymmdd_hhnnss") & ".xlsx"
    
    rs.Close
    objWorkbook.Close
    objExcel.Quit
    
    Exit Sub
    
ErrorHandler:
    Call CleanupExcel objExcel, objWorkbook
    Call LogError(Err, "ExportToExcel")
    
End Sub


Private Sub CleanupExcel(objExcel As Excel.Application, _
                          Optional objWorkbook As Excel.Workbook)
    
    On Error Resume Next
    
    If Not objWorkbook Is Nothing Then
        objWorkbook.Close False
        Set objWorkbook = Nothing
    End If
    
    If Not objExcel Is Nothing Then
        objExcel.Quit
        Set objExcel = Nothing
    End If
    
End Sub
```

### 7.2 Outlook操作模板

```vba
' ============ Outlook邮件操作 ============

Public Sub SendEmail(strTo As String, _
                     strSubject As String, _
                     strBody As String, _
                     Optional strCC As String = "", _
                     Optional strAttachment As String = "")
    
    On Error GoTo ErrorHandler
    
    Dim objOutlook As Outlook.Application
    Dim objMail As Outlook.MailItem
    
    Set objOutlook = New Outlook.Application
    Set objMail = objOutlook.CreateItem(olMailItem)
    
    With objMail
        .To = strTo
        .CC = strCC
        .Subject = strSubject
        .Body = strBody
        .Importance = olImportanceNormal
        
        If strAttachment <> "" Then
            .Attachments.Add strAttachment
        End If
        
        .Send
    End With
    
    Set objMail = Nothing
    Set objOutlook = Nothing
    
    Exit Sub
    
ErrorHandler:
    Call LogError(Err, "SendEmail")
    
End Sub
```

---

## 8. 常用代码模板

### 8.1 窗体模块模板

```vba
' ============ 窗体模块模板 ============

Option Explicit

' 控件声明（命名约定：前缀 + 描述）
Private WithEvents txtUserName As MSForms.TextBox
Private WithEvents txtPassword As MSForms.TextBox
Private WithEvents btnLogin As MSForms.CommandButton
Private WithEvents btnCancel As MSForms.CommandButton

' 模块级变量
Private m_objUser As clsUser


'--------------------------------------------------------------
' 窗体初始化
'--------------------------------------------------------------
Private Sub UserForm_Initialize()
    
    Me.Caption = "用户登录"
    Me.Width = 300
    Me.Height = 200
    
    Call InitializeControls
    Call LoadSavedCredentials
    
End Sub


'--------------------------------------------------------------
' 登录按钮点击事件
'--------------------------------------------------------------
Private Sub btnLogin_Click()
    
    On Error GoTo ErrorHandler
    
    Dim strUserName As String
    Dim strPassword As String
    
    ' 获取输入
    strUserName = txtUserName.Text
    strPassword = txtPassword.Text
    
    ' 验证输入
    If strUserName = "" Then
        MsgBox "请输入用户名", vbExclamation
        txtUserName.SetFocus
        Exit Sub
    End If
    
    ' 执行登录
    If modAuth.ValidateLogin(strUserName, strPassword) Then
        MsgBox "登录成功", vbInformation
        Me.Hide
        frmMain.Show
    Else
        MsgBox "用户名或密码错误", vbExclamation
        txtPassword.Text = ""
        txtPassword.SetFocus
    End If
    
    Exit Sub
    
ErrorHandler:
    Call modError.HandleError(Err, "btnLogin_Click")
    
End Sub


'--------------------------------------------------------------
' 取消按钮点击事件
'--------------------------------------------------------------
Private Sub btnCancel_Click()
    Me.Hide
End Sub
```

### 8.2 类模块模板

```vba
' ============ 类模块：clsUser ============
Option Explicit

' 私有变量
Private m_lngUserID As Long
Private m_strUserName As String
Private m_strEmail As String
Private m_strPhone As String
Private m_enmStatus As UserStatus
Private m_dtCreateTime As Date

' 属性：UserID
Public Property Get UserID() As Long
    UserID = m_lngUserID
End Property

Public Property Let UserID(ByVal Value As Long)
    If Value <= 0 Then
        Err.Raise vbObjectError + 1001, "clsUser", "无效的用户ID"
    End If
    m_lngUserID = Value
End Property

' 属性：UserName
Public Property Get UserName() As String
    UserName = m_strUserName
End Property

Public Property Let UserName(ByVal Value As String)
    If Len(Trim(Value)) = 0 Then
        Err.Raise vbObjectError + 1002, "clsUser", "用户名不能为空"
    End If
    m_strUserName = Trim(Value)
End Property

' 属性：Email
Public Property Get Email() As String
    Email = m_strEmail
End Property

Public Property Let Email(ByVal Value As String)
    If Not IsValidEmail(Value) Then
        Err.Raise vbObjectError + 1003, "clsUser", "无效的邮箱格式"
    End If
    m_strEmail = Value
End Property

' 方法：保存
Public Sub Save()
    
    On Error GoTo ErrorHandler
    
    Dim strSQL As String
    
    If m_lngUserID = 0 Then
        ' 新增
        strSQL = "INSERT INTO Users (UserName, Email, Phone, Status) VALUES ('" & _
                 m_strUserName & "', '" & m_strEmail & "', '" & _
                 m_strPhone & "', " & m_enmStatus & ")"
    Else
        ' 更新
        strSQL = "UPDATE Users SET UserName = '" & m_strUserName & "', " & _
                 "Email = '" & m_strEmail & "', Phone = '" & m_strPhone & "', " & _
                 "Status = " & m_enmStatus & " WHERE UserID = " & m_lngUserID
    End If
    
    g_Conn.Execute strSQL
    
    Exit Sub
    
ErrorHandler:
    Call modError.LogError(Err, "clsUser.Save")
    
End Sub

' 方法：删除
Public Sub Delete()
    
    On Error GoTo ErrorHandler
    
    If m_lngUserID = 0 Then
        Exit Sub
    End If
    
    g_Conn.Execute "DELETE FROM Users WHERE UserID = " & m_lngUserID
    
End Sub

' 私有方法：验证邮箱
Private Function IsValidEmail(strEmail As String) As Boolean
    
    IsValidEmail = False
    
    If Len(Trim(strEmail)) = 0 Then
        Exit Function
    End If
    
    If InStr(strEmail, "@") > 0 And InStr(strEmail, ".") > 0 Then
        IsValidEmail = True
    End If
    
End Function
```

---

## 9. 最佳实践清单

### ✅ 推荐做法
```
1. 使用 Option Explicit 强制变量声明
2. 每个变量单独声明
3. 过程/函数使用清晰的中文或英文命名
4. 添加过程级错误处理
5. 释放对象引用（Set obj = Nothing）
6. 使用常量替代魔法数字
7. 使用类模块封装业务逻辑
8. 窗体代码与业务逻辑分离
9. 使用事务确保数据一致性
10. 记录操作日志
11. 代码块之间添加空行
12. 使用行继续符 _ 格式化长代码
```

### ❌ 避免做法
```
1. 避免使用未声明的变量
2. 避免使用 Variant 类型（除非必要）
3. 避免使用 GoTo 跳转（错误处理除外）
4. 避免在循环中进行数据库操作
5. 避免硬编码连接字符串
6. 避免使用 SELECT * 查询
7. 避免在窗体模块中编写业务逻辑
8. 避免忽略错误继续执行
9. 避免使用默认的布尔比较（使用 = True/False）
10. 避免过长的过程（建议不超过100行）
```

---