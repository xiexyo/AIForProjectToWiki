# JavaScript/TypeScript 编码规范
版本: 1.0 

## 1. 命名规范

### 1.1 命名约定总览

| 类型               | 命名风格         | 示例                           |
|--------------------|------------------|--------------------------------|
| 变量/函数          | camelCase        | userName, getUserById          |
| 类/接口/类型       | PascalCase       | UserService, OrderController   |
| 常量               | UPPER_SNAKE      | MAX_RETRY_COUNT, API_BASE_URL  |
| 枚举               | PascalCase(值)   | UserStatus.Active              |
| 私有属性/方法      | _前缀 或 #前缀   | _privateMethod, #privateField  |
| 组件名             | PascalCase       | UserList, OrderCard            |
| CSS类名            | kebab-case       | user-card, order-list          |
| 文件名             | kebab-case       | user-service.ts, order-utils.js|

### 1.2 详细命名示例

```typescript
// ============ 变量命名 ============

// 普通变量
let userName = '张三';
let isActive = true;
let userCount = 100;

// 常量
const MAX_RETRY_COUNT = 3;
const API_BASE_URL = 'https://api.example.com';

// 布尔变量：is/has/can/should 前缀
let isLoading = false;
let hasPermission = true;
let canEdit = false;

// 数组/集合：复数名词
let users = [];
let userList = [];
let orderItems = [];

// 函数：动词或动词短语
function getUserById(id) {}
function validateEmail(email) {}
function handleClick(event) {}

// 私有变量：_ 前缀（JS）或 # 前缀（TS类）
class UserService {
  private _cache = new Map();
  #privateField = 'secret';
}

// ============ TypeScript 类型命名 ============

// 接口
interface User {
  id: number;
  name: string;
  email: string;
}

// 类型别名
type UserStatus = 'active' | 'inactive' | 'banned';

// 枚举
enum OrderStatus {
  Pending = 'pending',
  Paid = 'paid',
  Shipped = 'shipped',
  Completed = 'completed'
}

// 泛型参数
function getFirst<T>(items: T[]): T | undefined {}

// ============ 错误示例 ============

// ❌ 变量命名不当
let x, y, z;  // 无意义
let data;     // 太笼统
let flag;     // 不明确
const n = 100;  // 单字母
const MAX = 100;  // 缺少下划线

// ✅ 正确命名
let userAge = 25;
let orderTotal = 199.99;
let isFormValid = false;
const MAX_RETRY_COUNT = 3;
```

---

## 2. 代码格式规范

### 2.1 缩进与空白

```typescript
// 缩进：2个空格（或配置ESLint/Prettier）

// ✅ 正确示例
function calculateTotal(items) {
  let subtotal = 0;
  
  for (const item of items) {
    subtotal += item.price * item.quantity;
  }
  
  return subtotal;
}

// ✅ 箭头函数格式化
const multiply = (a, b) => a * b;

const processItems = (items) => {
  return items
    .filter(item => item.isActive)
    .map(item => item.name);
};

// ✅ 对象格式化
const user = {
  id: 1,
  name: '张三',
  email: 'zhangsan@example.com',
  isActive: true,
};

// ✅ 解构赋值
const { id, name, email } = user;
const [first, second, ...rest] = items;
```

### 2.2 导入语句

```typescript
// ✅ 导入顺序：内置模块 → 外部模块 → 内部模块
// 组间空行，按路径长度排序

import React from 'react';
import { useState, useEffect } from 'react';

// 第三方库
import { useDispatch, useSelector } from 'react-redux';
import { Button, Modal } from 'antd';
import classNames from 'classnames';

// 本地模块
import { UserService } from '@/services/user-service';
import { formatDate } from '@/utils/date-utils';
import { UserCard } from '@/components/user-card';
import type { User } from '@/types';

// ❌ 避免通配符导入
import * as Utils from './utils';

// ✅ 使用 type 导入类型
import type { User, Order } from '@/types';
import { User, Order } from '@/models';  // 值导入
```

### 2.3 引号与分号

```typescript
// ✅ 使用单引号定义字符串
const name = '张三';
const message = "Hello, world";

// ✅ 使用反引号处理模板字符串
const greeting = `Hello, ${name}!`;
const sql = `SELECT * FROM users WHERE id = ${userId}`;

// ✅ 始终添加分号
const sum = a + b;

// ✅ 使用 === 而非 ==
if (value === 'active') { }
if (count !== 0) { }

// ✅ 使用 ?? 操作符处理 null/undefined
const defaultValue = input ?? 'default';
const result = value ?? 0;

// ✅ 使用 ?. 可选链
const city = user?.profile?.address?.city;
const firstItem = items?.[0];
```

---

## 3. TypeScript 类型系统

### 3.1 类型定义规范

```typescript
// ============ 接口 vs 类型别名 ============

// ✅ 接口：用于定义对象结构
interface User {
  id: number;
  name: string;
  email: string;
  isActive: boolean;
  createdAt: Date;
}

// ✅ 类型别名：用于联合类型、交叉类型
type UserStatus = 'active' | 'inactive' | 'banned';
type UserOrGuest = User | Guest;
type CompleteUser = User & BaseInfo & ContactInfo;

// ✅ 可选属性
interface Config {
  host: string;
  port?: number;
  timeout?: number;
}

// ✅ 只读属性
interface Point {
  readonly x: number;
  readonly y: number;
}

// ✅ 索引签名
interface StringMap {
  [key: string]: string;
}

// ✅ 函数类型
interface Validator {
  (value: any): boolean;
  errorMessage?: string;
}

// ✅ 类类型
interface Serializable {
  serialize(): string;
  deserialize(data: string): void;
}
```

### 3.2 泛型使用

```typescript
// ✅ 泛型函数
function identity<T>(arg: T): T {
  return arg;
}

// ✅ 泛型约束
interface HasLength {
  length: number;
}

function logLength<T extends HasLength>(arg: T): number {
  return arg.length;
}

// ✅ 多泛型参数
function map<K, V>(obj: Record<K, V>, fn: (v: V) => V): Record<K, V> {
  const result = {} as Record<K, V>;
  for (const key in obj) {
    result[key] = fn(obj[key]);
  }
  return result;
}

// ✅ 泛型接口
interface Repository<T> {
  findById(id: number): Promise<T | null>;
  findAll(): Promise<T[]>;
  save(entity: T): Promise<T>;
  delete(id: number): Promise<void>;
}

// ✅ 泛型类
class DataStore<T> {
  private items: T[] = [];
  
  add(item: T): void {
    this.items.push(item);
  }
  
  getAll(): T[] {
    return [...this.items];
  }
}
```

### 3.3 实用类型

```typescript
// ✅ Partial：所有属性可选
type PartialUser = Partial<User>;

// ✅ Required：所有属性必填
type RequiredUser = Required<User>;

// ✅ Pick：选择部分属性
type UserBasicInfo = Pick<User, 'id' | 'name'>;

// ✅ Omit：排除部分属性
type UserWithoutEmail = Omit<User, 'email'>;

// ✅ Record：键值对
type UserMap = Record<string, User>;

// ✅ Exclude 和 Extract
type Status = 'pending' | 'active' | 'inactive' | 'banned';
type ActiveStatus = Extract<Status, 'active' | 'inactive'>;
type InactiveStatus = Exclude<Status, 'active'>;

// ✅ ReturnType：获取函数返回类型
function getUser() {
  return { id: 1, name: '张三' };
}
type User = ReturnType<typeof getUser>;
```

---

## 4. 函数设计

### 4.1 函数规范

```typescript
// ✅ 使用箭头函数
const add = (a: number, b: number): number => a + b;

// ✅ 明确返回类型
function getUserById(id: number): User | null {
  return users.find(u => u.id === id) ?? null;
}

// ✅ 使用默认参数
function createUser(name: string, age: number = 18): User {
  return { name, age };
}

// ✅ 剩余参数
function sum(...numbers: number[]): number {
  return numbers.reduce((acc, n) => acc + n, 0);
}

// ✅ 解构参数
function createUser({ name, email, age = 18 }: CreateUserInput): User {
  return { name, email, age };
}

// ✅ 异步函数
async function fetchUser(id: number): Promise<User> {
  const response = await fetch(`/api/users/${id}`);
  if (!response.ok) {
    throw new Error('Failed to fetch user');
  }
  return response.json();
}

// ✅ 函数组合
const pipe = (...fns) => (x) => fns.reduce((v, f) => f(v), x);
const processUser = pipe(validateUser, normalizeUser, saveUser);
```

### 4.2 错误处理

```typescript
// ✅ 使用 Error 对象
function validateEmail(email: string): void {
  if (!email.includes('@')) {
    throw new Error('Invalid email format');
  }
}

// ✅ 自定义错误类
class ValidationError extends Error {
  constructor(
    message: string,
    public field: string
  ) {
    super(message);
    this.name = 'ValidationError';
  }
}

// ✅ Try-catch
async function loadData() {
  try {
    const response = await fetch('/api/data');
    const data = await response.json();
    return data;
  } catch (error) {
    if (error instanceof NetworkError) {
      handleNetworkError();
    } else {
      handleUnknownError(error);
    }
  }
}

// ✅ Result 类型（可选）
type Result<T, E = Error> = 
  | { success: true; data: T }
  | { success: false; error: E };

async function fetchUser(id: number): Promise<Result<User>> {
  try {
    const user = await api.getUser(id);
    return { success: true, data: user };
  } catch (error) {
    return { success: false, error: error as Error };
  }
}
```

---

## 5. React 组件规范

### 5.1 组件定义

```tsx
// ============ 函数组件（推荐） ============

import React, { useState, useEffect, memo } from 'react';
import type { FC } from 'react';
import { UserCard } from './user-card';
import styles from './user-list.module.css';

// Props 接口
interface UserListProps {
  users: User[];
  onUserClick?: (user: User) => void;
  isLoading?: boolean;
  maxCount?: number;
}

// 组件定义
export const UserList: FC<UserListProps> = memo(({ 
  users, 
  onUserClick,
  isLoading = false,
  maxCount = 10 
}) => {
  // 状态
  const [searchTerm, setSearchTerm] = useState('');
  
  // 计算属性
  const filteredUsers = React.useMemo(() => {
    return users
      .filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .slice(0, maxCount);
  }, [users, searchTerm, maxCount]);
  
  // 副作用
  useEffect(() => {
    document.title = `用户列表 (${filteredUsers.length})`;
  }, [filteredUsers.length]);
  
  // 事件处理
  const handleUserClick = (user: User) => {
    onUserClick?.(user);
  };
  
  // 渲染
  if (isLoading) {
    return <div className={styles.loading}>加载中...</div>;
  }
  
  return (
    <div className={styles.container}>
      <input
        type="text"
        placeholder="搜索用户..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className={styles.searchInput}
      />
      
      <div className={styles.list}>
        {filteredUsers.map(user => (
          <UserCard
            key={user.id}
            user={user}
            onClick={() => handleUserClick(user)}
          />
        ))}
      </div>
    </div>
  );
});

UserList.displayName = 'UserList';
```

### 5.2 Hooks 使用规范

```tsx
// ✅ 自定义 Hook 命名：以 use 开头
function useUser(userId: number) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  
  useEffect(() => {
    let cancelled = false;
    
    async function loadUser() {
      try {
        setIsLoading(true);
        const data = await fetchUser(userId);
        if (!cancelled) {
          setUser(data);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err as Error);
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }
    
    loadUser();
    
    return () => {
      cancelled = true;
    };
  }, [userId]);
  
  return { user, isLoading, error };
}

// ✅ 使用自定义 Hook
function UserProfile({ userId }: { userId: number }) {
  const { user, isLoading, error } = useUser(userId);
  
  if (isLoading) return <Spinner />;
  if (error) return <ErrorMessage error={error} />;
  if (!user) return <NotFound />;
  
  return <div>{user.name}</div>;
}
```

---

## 6. Node.js/Express 规范

### 6.1 项目结构

```
src/
├── config/           # 配置文件
│   ├── index.ts
│   └── database.ts
├── controllers/      # 控制器
│   ├── user.controller.ts
│   └── order.controller.ts
├── middleware/       # 中间件
│   ├── auth.middleware.ts
│   ├── error.middleware.ts
│   └── validation.middleware.ts
├── models/          # 数据模型
│   ├── user.model.ts
│   └── order.model.ts
├── routes/          # 路由
│   ├── user.routes.ts
│   └── order.routes.ts
├── services/        # 业务逻辑
│   ├── user.service.ts
│   └── order.service.ts
├── utils/           # 工具函数
│   ├── logger.ts
│   └── validator.ts
├── types/           # 类型定义
│   └── index.ts
├── app.ts           # 应用入口
└── server.ts        # 服务器启动
```

### 6.2 API 路由模板

```typescript
// routes/user.routes.ts
import { Router } from 'express';
import { UserController } from '@/controllers/user.controller';
import { AuthMiddleware } from '@/middleware/auth.middleware';
import { ValidationMiddleware } from '@/middleware/validation.middleware';
import { body, param } from 'express-validator';

const router = Router();
const userController = new UserController();

// 获取用户列表
router.get(
  '/',
  AuthMiddleware.verifyToken,
  userController.getUsers
);

// 获取单个用户
router.get(
  '/:id',
  AuthMiddleware.verifyToken,
  ValidationMiddleware.validate([
    param('id').isInt().toInt()
  ]),
  userController.getUserById
);

// 创建用户
router.post(
  '/',
  ValidationMiddleware.validate([
    body('username').isString().trim().isLength({ min: 3, max: 20 }),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 6 })
  ]),
  userController.createUser
);

// 更新用户
router.put(
  '/:id',
  AuthMiddleware.verifyToken,
  ValidationMiddleware.validate([
    param('id').isInt().toInt(),
    body('username').optional().isString().trim(),
    body('email').optional().isEmail().normalizeEmail()
  ]),
  userController.updateUser
);

// 删除用户
router.delete(
  '/:id',
  AuthMiddleware.verifyToken,
  ValidationMiddleware.validate([
    param('id').isInt().toInt()
  ]),
  userController.deleteUser
);

export default router;
```

### 6.3 控制器模板

```typescript
// controllers/user.controller.ts
import { Request, Response, NextFunction } from 'express';
import { UserService } from '@/services/user.service';
import { ValidationError } from '@/utils/errors';

const userService = new UserService();

export class UserController {
  
  /**
   * 获取用户列表
   */
  async getUsers(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { page = 1, limit = 20 } = req.query;
      
      const result = await userService.getUsers({
        page: Number(page),
        limit: Number(limit)
      });
      
      res.json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
    } catch (error) {
      next(error);
    }
  }
  
  /**
   * 根据ID获取用户
   */
  async getUserById(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const id = req.params.id as unknown as number;
      const user = await userService.getUserById(id);
      
      if (!user) {
        throw new ValidationError('用户不存在', 'id');
      }
      
      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      next(error);
    }
  }
  
  /**
   * 创建用户
   */
  async createUser(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { username, email, password } = req.body;
      
      const user = await userService.createUser({
        username,
        email,
        password
      });
      
      res.status(201).json({
        success: true,
        data: user
      });
    } catch (error) {
      next(error);
    }
  }
}
```

---

## 7. 最佳实践清单

### ✅ 推荐做法
```
1. 使用 TypeScript 增强类型安全
2. 使用 ESLint + Prettier 统一代码风格
3. 使用 const 声明不会改变的变量
4. 使用解构赋值提高可读性
5. 使用可选链 ?. 和空值合并 ?? 操作符
6. 使用 async/await 处理异步操作
7. 使用 Promise.all 并行处理独立任务
8. 使用模块化导入减少包体积
9. 使用 React.memo 优化组件渲染
10. 使用 useMemo/useCallback 缓存计算结果
11. 使用环境变量管理敏感配置
12. 使用统一的错误处理机制
```

### ❌ 避免做法
```
1. 避免使用 var，优先使用 let/const
2. 避免使用 any 类型
3. 避免直接修改函数参数
4. 避免在循环中调用异步函数
5. 避免使用 eval()
6. 避免使用 with 语句
7. 避免使用隐式类型转换
8. 避免在 useEffect 中忽略依赖数组
9. 避免直接修改 state 对象
10. 避免在 render 中执行复杂计算
```
