# Shell 脚本编码规范
版本: 1.0

## 1. 命名规范

### 1.1 脚本命名

```bash
# ✅ 脚本文件名使用 kebab-case
deploy-application.sh
backup-database.sh
check-service-status.sh

# ✅ 脚本权限：755
chmod +x deploy-application.sh

# ❌ 避免
DeployScript.SH    # 大小写混用
script1.sh         # 名称不明确
```

### 1.2 变量命名

```bash
# ✅ 普通变量：小写 + 下划线
user_name="张三"
database_host="localhost"
max_retry_count=3

# ✅ 常量：大写 + 下划线
readonly MAX_RETRY_COUNT=3
readonly LOG_FILE="/var/log/app.log"
readonly API_BASE_URL="https://api.example.com"

# ✅ 数组变量
declare -a user_ids=(1 2 3 4 5)
declare -A config_map  # 关联数组

# ✅ 函数名：小写 + 下划线
function get_user_by_id() { }
function calculate_total() { }
function send_notification() { }

# ❌ 避免
userName="test"       # camelCase
USER_NAME="test"      # 变量不用大写
```

---

## 2. 脚本结构规范

### 2.1 标准脚本模板

```bash
#!/usr/bin/env bash
#===============================================================================
# 脚本名称：deploy-application.sh
# 描述：应用部署脚本
# 作者：张三
# 创建日期：2024-01-01
# 修改历史：
#   2024-01-15 李四 - 添加回滚功能
#===============================================================================

set -euo pipefail  # 建议添加

# -------------------- 变量定义 --------------------
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}")"
readonly LOG_FILE="/var/log/${SCRIPT_NAME%.sh}.log"

# 配置变量
readonly APP_NAME="myapp"
readonly APP_VERSION="1.0.0"
readonly DEPLOY_DIR="/opt/${APP_NAME}"
readonly BACKUP_DIR="/opt/backups"

# 颜色定义（可选）
readonly COLOR_RED='\033[0;31m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_YELLOW='\033[1;33m'
readonly COLOR_NC='\033[0m' # No Color

# -------------------- 函数定义 --------------------
function log_info() {
    echo -e "${COLOR_GREEN}[INFO]${COLOR_NC} $*" | tee -a "${LOG_FILE}"
}

function log_warn() {
    echo -e "${COLOR_YELLOW}[WARN]${COLOR_NC} $*" | tee -a "${LOG_FILE}"
}

function log_error() {
    echo -e "${COLOR_RED}[ERROR]${COLOR_NC} $*" | tee -a "${LOG_FILE}" >&2
}

function usage() {
    cat << EOF
用法: ${SCRIPT_NAME} [选项]

选项:
    -h, --help          显示帮助信息
    -v, --version       显示版本信息
    -e, --env ENV       部署环境 (dev|test|prod)
    -r, --rollback      回滚到上一版本

示例:
    ${SCRIPT_NAME} -e prod
    ${SCRIPT_NAME} -r
EOF
}

function check_dependencies() {
    log_info "检查依赖..."

    local deps=("git" "docker" "kubectl")
    for dep in "${deps[@]}"; do
        if ! command -v "${dep}" &> /dev/null; then
            log_error "缺少依赖: ${dep}"
            exit 1
        fi
    done

    log_info "依赖检查完成"
}

function backup_current() {
    log_info "备份当前版本..."
    
    if [[ -d "${DEPLOY_DIR}" ]]; then
        local backup_name="${APP_NAME}_$(date +%Y%m%d_%H%M%S)"
        local backup_path="${BACKUP_DIR}/${backup_name}"
        
        mkdir -p "${BACKUP_DIR}"
        cp -r "${DEPLOY_DIR}" "${backup_path}"
        
        log_info "备份已保存至: ${backup_path}"
    fi
}

function deploy() {
    local env="${1:-prod}"
    
    log_info "开始部署应用..."
    log_info "部署环境: ${env}"
    
    # 拉取代码
    log_info "拉取最新代码..."
    cd "${DEPLOY_DIR}"
    git pull origin main
    
    # 构建镜像
    log_info "构建Docker镜像..."
    docker build -t "${APP_NAME}:${APP_VERSION}" .
    
    # 部署
    log_info "部署到K8s..."
    kubectl apply -f k8s/deployment.yaml
    
    # 验证
    log_info "验证部署状态..."
    sleep 10
    kubectl rollout status deployment/${APP_NAME}
    
    log_info "部署完成!"
}

function rollback() {
    log_info "开始回滚..."
    
    local latest_backup
    latest_backup=$(ls -t "${BACKUP_DIR}"/${APP_NAME}_* 2>/dev/null | head -1)
    
    if [[ -z "${latest_backup}" ]]; then
        log_error "没有找到可用的备份"
        exit 1
    fi
    
    log_info "回滚到: ${latest_backup}"
    rm -rf "${DEPLOY_DIR}"
    cp -r "${latest_backup}" "${DEPLOY_DIR}"
    
    log_info "回滚完成!"
}

# -------------------- 主流程 --------------------
function main() {
    # 解析参数
    local env="prod"
    local do_rollback=false
    
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                usage
                exit 0
                ;;
            -v|--version)
                echo "${APP_NAME} v${APP_VERSION}"
                exit 0
                ;;
            -e|--env)
                env="$2"
                shift 2
                ;;
            -r|--rollback)
                do_rollback=true
                shift
                ;;
            *)
                log_error "未知参数: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    # 前置检查
    check_dependencies
    
    # 执行任务
    if [[ "${do_rollback}" == true ]]; then
        rollback
    else
        backup_current
        deploy "${env}"
    fi
}

# 入口
main "$@"
```

---

## 3. 常用命令模板

### 3.1 字符串处理

```bash
# ============ 字符串操作 ============

# 字符串长度
str="Hello World"
echo ${#str}  # 11

# 字符串切片
echo ${str:6}      # World
echo ${str:0:5}    # Hello

# 字符串替换
echo ${str/World/Bash}  # Hello Bash
echo ${str//o/O}        # HellO WOrld (全局替换)

# 字符串前缀/后缀删除
path="/home/user/file.txt"
echo ${path##*/}   # file.txt (删除最长匹配前缀)
echo ${path%/*}     # /home/user (删除最短匹配后缀)

# 字符串连接
str1="Hello"
str2="World"
result="${str1} ${str2}"  # Hello World

# 字符串转大写/小写
echo ${str^^}  # HELLO WORLD
echo ${str,,}  # hello world

# 字符串分割成数组
IFS='|' read -ra items <<< "苹果|香蕉|橙子"
for item in "${items[@]}"; do
    echo "$item"
done

# ============ 字符串比较 ============

str1="hello"
str2="world"

# 字符串比较用 ==
if [[ "$str1" == "hello" ]]; then
    echo "匹配"
fi

# 正则匹配
if [[ "$str1" =~ ^hel ]]; then
    echo "以hel开头"
fi

# 模式匹配
if [[ "$str" == *World* ]]; then
    echo "包含World"
fi
```

### 3.2 文件操作

```bash
# ============ 文件检查 ============

file="/path/to/file.txt"

# 检查文件存在
if [[ -e "${file}" ]]; then
    echo "文件存在"
fi

# 检查是文件还是目录
[[ -f "${file}" ]] && echo "是普通文件"
[[ -d "${file}" ]] && echo "是目录"
[[ -L "${file}" ]] && echo "是符号链接"

# 检查文件属性
[[ -r "${file}" ]] && echo "可读"
[[ -w "${file}" ]] && echo "可写"
[[ -x "${file}" ]] && echo "可执行"

# 检查是否为空
[[ -s "${file}" ]] && echo "文件非空"

# ============ 文件读取 ============

# 读取文件每一行
while IFS= read -r line; do
    echo "行: $line"
done < "${file}"

# 读取文件到数组
mapfile -t lines < "${file}"
for line in "${lines[@]}"; do
    echo "$line"
done

# 读取配置
while IFS='=' read -r key value; do
    echo "key=$key, value=$value"
done < config.txt

# ============ 文件写入 ============

# 写入文件（覆盖）
cat > "${file}" << EOF
第一行内容
第二行内容
变量替换: ${variable}
EOF

# 追加内容
cat >> "${file}" << EOF
追加的内容
EOF

# ============ 目录操作 ============

# 创建目录
mkdir -p /path/to/dir/{subdir1,subdir2,subdir3}

# 递归复制
cp -r source_dir/* dest_dir/

# 递归删除（危险！）
rm -rf /path/to/dir

# 获取绝对路径
abs_path=$(realpath "./relative/path")
```

### 3.3 数组操作

```bash
# ============ 数组定义 ============

# 普通数组
fruits=("苹果" "香蕉" "橙子")
numbers=(1 2 3 4 5)

# 关联数组（需要声明）
declare -A user_info
user_info["name"]="张三"
user_info["email"]="zhangsan@example.com"

# ============ 数组操作 ============

# 获取长度
echo ${#fruits[@]}  # 3

# 访问元素
echo ${fruits[0]}   # 苹果
echo ${fruits[-1]}  # 橙子（最后一个）

# 遍历数组
for fruit in "${fruits[@]}"; do
    echo "$fruit"
done

# 获取索引
for i in "${!fruits[@]}"; do
    echo "$i: ${fruits[$i]}"
done

# 切片
echo ${fruits[@]:1:2}  # 香蕉 橙子

# 添加元素
fruits+=("葡萄")

# 删除元素
unset fruits[1]  # 删除第二个元素

# 排序
sorted=($(for i in "${fruits[@]}"; do echo $i; done | sort))

# ============ 关联数组 ============

# 遍历
for key in "${!user_info[@]}"; do
    echo "$key: ${user_info[$key]}"
done

# 获取所有值
echo "${user_info[@]}"

# 获取所有键
echo "${!user_info[@]}"
```

---

## 4. 错误处理规范

```bash
# ============ set 选项 ============

# 推荐选项
set -e          # 命令失败时退出
set -u          # 使用未定义变量时报错
set -o pipefail # 管道中任何命令失败都视为失败
# 建议在脚本开头设置
set -euo pipefail

# ============ 错误检查 ============

# 检查命令执行结果
if command; then
    echo "成功"
else
    echo "失败"
fi

# 检查返回值
./script.sh
if [[ $? -eq 0 ]]; then
    echo "执行成功"
fi

# ============ 自定义错误 ============

function error_exit() {
    echo "ERROR: $1" >&2
    exit "${2:-1}"
}

# 使用
[[ -f "$file" ]] || error_exit "文件不存在" 2
[[ "$value" -gt 0 ]] || error_exit "值必须大于0" 3

# ============ 陷阱处理 ============

function cleanup() {
    echo "清理临时文件..."
    rm -f /tmp/temp_*
}

function on_error() {
    local exit_code=$?
    echo "发生错误，退出码: $exit_code"
    cleanup
    exit "$exit_code"
}

# 设置陷阱
trap cleanup EXIT      # 退出时清理
trap on_error ERR      # 错误时处理
trap "echo '收到信号'; exit" INT TERM  # 信号处理

# ============ 超时处理 ============

function timeout_handler() {
    echo "命令执行超时"
    exit 124
}

timeout 10s long_running_command || {
    if [[ $? -eq 124 ]]; then
        echo "命令超时"
    fi
}
```

---

## 5. 最佳实践清单

### ✅ 推荐做法
```
1. 使用 #!/usr/bin/env bash 而不是 #!/bin/bash
2. 脚本开头设置 set -euo pipefail
3. 变量引用使用双引号 "${var}"
4. 变量和函数使用有意义的名称
5. 重要路径使用 readonly 定义常量
6. 使用errexit、pipefail选项
7. 添加日志记录关键操作
8. 错误处理使用 trap
9. 使用函数封装重复代码
10. 清理临时文件和资源
11. 添加 -h/--help 帮助信息
12. 脚本权限设置为 755
```

### ❌ 避免做法
```
1. 避免使用 sh 而非 bash
2. 避免变量不用引号包裹
3. 避免使用 eval
4. 避免使用未声明的变量
5. 避免在字符串中使用 $变量 不加引号
6. 避免 rm -rf 使用通配符
7. 避免命令替换使用反引号 `
8. 避免使用全局变量
9. 避免过长的单行命令
10. 避免在循环中执行外部命令
```
