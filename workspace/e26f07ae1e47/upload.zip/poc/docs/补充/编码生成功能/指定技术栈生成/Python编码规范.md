# Python 编码规范
版本: 1.0  | 基于 PEP 8

## 1. 命名规范

### 1.1 命名约定总览

| 类型               | 命名风格      | 示例                        |
|--------------------|---------------|-----------------------------|
| 模块/包            | 全小写下划线  | `user_service`, `order_handler` |
| 类名               | PascalCase    | `UserService`, `OrderController` |
| 函数/方法          | snake_case    | `get_user_by_id()`          |
| 实例变量           | snake_case    | `self.user_name`            |
| 类变量             | snake_case    | `default_timeout = 30`      |
| 常量               | UPPER_SNAKE   | `MAX_RETRY_COUNT`           |
| 函数参数           | snake_case    | `user_id`, `order_number`   |
| 私有属性/方法      | _前缀         | `_internal_method()`        |
| 特殊属性           | __前缀__      | `__init__`, `__str__`       |
| 布尔返回值函数     | is/has/can开头| `is_valid`, `has_permission` |

### 1.2 详细命名示例

```python
# ✅ 正确示例

# 模块命名
import user_service
from utils import database_helper

# 类命名
class UserService:
    """用户服务类"""

    DEFAULT_PAGE_SIZE = 20

    def __init__(self, repository):
        self._repository = repository
        self._cache = {}

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """根据ID获取用户"""
        if user_id in self._cache:
            return self._cache[user_id]
        return self._repository.find_by_id(user_id)

    def _build_user_response(self, user: User) -> dict:
        """私有方法：构建用户响应"""
        pass

    def is_active(self) -> bool:
        """返回布尔值的方法"""
        return self.status == UserStatus.ACTIVE

# 私有模块
def _private_helper():
    pass

# 常量
MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # 10MB
API_BASE_URL = "https://api.example.com"


# ❌ 错误示例

class userService:  # 类名应为PascalCase
    pass

def GetUserById(userID):  # 函数名应为snake_case
    pass

userName = "test"  # 变量应为snake_case
MAXRETRY = 3  # 常量应为UPPER_SNAKE
```

---

## 2. 代码格式规范

### 2.1 缩进与空白

```python
# 缩进：4个空格（禁用Tab）
# 行长度：普通代码≤79字符，文档≤72字符

# ✅ 正确示例
def calculate_total(items: List[OrderItem],
                    tax_rate: float,
                    discount: float) -> Decimal:
    """
    计算订单总金额
    """
    subtotal = sum(item.price * item.quantity for item in items)
    discounted = subtotal * (1 - discount)
    return discounted * (1 + tax_rate)

# 长行使用括号续行
total = (item1.price
         + item2.price
         + item3.price)

# 使用反斜杠续行（仅在必须时）
long_string = "This is a very long string that " \
              "spans multiple lines"


# ❌ 错误示例
def wrong_indent(x):  # 缺少空格
  if x > 0:  # 缩进不一致
      return x
```

### 2.2 导入语句

```python
# 导入顺序：标准库 → 第三方库 → 本地应用/库
# 组间空行，按字母顺序排列

# 标准库
import os
import sys
from datetime import datetime
from typing import List, Optional, Dict

# 第三方库
import django
from django.conf import settings
from flask import Blueprint, request

# 本地模块
from models import User, Order
from utils import helper
from services import user_service

# 避免使用 from module import *
# 推荐使用绝对导入
from package.subpackage import module
from . import sibling_module
```

### 2.3 空格使用规则

```python
# ✅ 括号内不加空格
result = function(arg1, arg2)
my_dict = {'key': 'value'}
my_list = [1, 2, 3]

# ✅ 赋值/关键字参数等号两边加空格
name = "value"
def func(a=1, b=2):
    pass

# ✅ 运算符两侧加空格
x = 1 + 2
y = x * 2 + 5

# ✅ 高优先级运算符可省略空格
x = x*2 + 1
c = (a + b) * (a - b)

# ❌ 错误示例
result = function( arg1, arg2 )  # 括号内不应有空格
x = x * 2 + 1  # 运算符两侧应有空格
```

### 2.4 空行使用规则

```python
# 模块顶层：两个空行
import os
import sys


class MyClass:
    # 类内方法：空一行
    def method_one(self):
        pass

    def method_two(self):
        pass


class AnotherClass:
    pass


# 函数内：使用空行分隔逻辑块
def process_data(data):
    # 第一步：数据验证
    if not data:
        raise ValueError("数据不能为空")

    # 第二步：数据转换
    cleaned = [item.strip() for item in data]

    # 第三步：业务处理
    results = []
    for item in cleaned:
        if item:
            results.append(item.upper())

    return results
```

---

## 3. 注释规范

### 3.1 注释类型与示例

```python
# ============ 单行注释 ============
# 这是一个单行注释，用于说明紧随其后的代码

MAX_RETRY = 3  # 行尾注释


# ============ 多行注释 ============
def calculate_total(items):
    """
    计算订单总金额

    Args:
        items: 订单商品列表

    Returns:
        Decimal: 总金额

    Raises:
        ValueError: 商品列表为空时抛出
    """
    if not items:
        raise ValueError("商品列表不能为空")

    # 计算小计
    subtotal = sum(item['price'] * item['quantity'] for item in items)

    return subtotal


# ============ 文档字符串示例 ============
class UserService:
    """
    用户服务类

    提供用户相关的业务逻辑处理，包括：
    - 用户注册与登录
    - 用户信息查询
    - 用户权限管理

    Attributes:
        repository: 用户数据仓库实例
        cache: 用户缓存字典

    Example:
        >>> service = UserService(repository)
        >>> user = service.get_user_by_id(1)
        >>> print(user.name)
    """

    def __init__(self, repository):
        """初始化用户服务"""
        self._repository = repository
        self._cache = {}
```

### 3.2 TODO/FIXME注释

```python
def complex_function(x):
    # TODO: 优化算法复杂度
    # 当前使用O(n²)，可以优化到O(n)
    for i in range(x):
        for j in range(x):
            pass

    # FIXME: 修复边界条件
    # 当x=0时会抛出异常
    return 1 / x
```

---

## 4. 类型注解

### 4.1 类型注解规范

```python
from typing import List, Dict, Optional, Union, Callable, TypeVar

# 函数参数和返回值注解
def greet(name: str) -> str:
    return f"Hello, {name}"

# 多个返回值类型注解
def get_user_info(user_id: int) -> tuple[str, str, int]:
    name = "John"
    email = "john@example.com"
    age = 30
    return name, email, age

# 使用Optional
def find_user(user_id: int) -> Optional[dict]:
    if user_id > 0:
        return {"id": user_id, "name": "User"}
    return None

# 复杂类型注解
def process_users(users: List[Dict[str, Union[str, int]]]) -> List[str]:
    return [f"{u['name']} ({u['age']})" for u in users]

# 可调用对象
def apply_func(func: Callable[[int], int], value: int) -> int:
    return func(value)

# 泛型
T = TypeVar('T')

def get_first(items: List[T]) -> Optional[T]:
    return items[0] if items else None
```

### 4.2 类型注解示例

```python
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime
from enum import Enum


class UserStatus(Enum):
    """用户状态枚举"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    BANNED = "banned"


@dataclass
class User:
    """用户数据类"""
    id: int
    username: str
    email: str
    status: UserStatus = UserStatus.ACTIVE
    created_at: Optional[datetime] = None
    tags: List[str] = field(default_factory=list)

    def is_active(self) -> bool:
        """判断用户是否激活"""
        return self.status == UserStatus.ACTIVE


class UserService:
    """用户服务类"""

    def __init__(self, repository: 'UserRepository') -> None:
        self._repository = repository
        self._cache: Dict[int, User] = {}

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """根据ID获取用户"""
        if user_id in self._cache:
            return self._cache[user_id]

        user = self._repository.find_by_id(user_id)
        if user:
            self._cache[user_id] = user
        return user

    def get_active_users(self, limit: int = 10) -> List[User]:
        """获取活跃用户列表"""
        all_users = self._repository.find_all()
        return [u for u in all_users if u.is_active()][:limit]
```

---

## 5. 函数与类设计

### 5.1 函数设计原则

```python
# ✅ 函数应该简短、单一职责
def validate_email(email: str) -> bool:
    """验证邮箱格式"""
    import re
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(pattern, email))


def validate_username(username: str) -> tuple[bool, str]:
    """验证用户名

    Returns:
        (是否有效, 错误信息)
    """
    if not username:
        return False, "用户名不能为空"
    if len(username) < 4:
        return False, "用户名至少4个字符"
    if len(username) > 20:
        return False, "用户名最多20个字符"
    return True, ""


# ✅ 使用默认参数默认值（不可变对象）
def create_user(name: str,
                tags: Optional[List[str]] = None,
                active: bool = True) -> dict:
    tags = tags or []  # 避免默认参数可变对象的陷阱
    return {"name": name, "tags": tags, "active": active}


# ✅ 关键字参数提高可读性
result = calculate_total(
    items=cart_items,
    tax_rate=0.08,
    discount=0.1,
    shipping_fee=10.0
)


# ✅ 使用生成器处理大数据
def read_large_file(file_path: str):
    """逐行读取大文件"""
    with open(file_path, 'r') as f:
        for line in f:
            yield line.strip()


# ❌ 避免副作用
def impure_function(items: list):
    items.append("modified")  # 修改了输入参数


# ✅ 纯函数
def pure_function(items: list) -> list:
    return items + ["modified"]
```

### 5.2 类设计原则

```python
# ✅ 使用dataclass简化数据类
from dataclasses import dataclass, field
from typing import List


@dataclass
class Point:
    x: float
    y: float

    def distance_to(self, other: 'Point') -> float:
        return ((self.x - other.x)**2 + (self.y - other.y)**2)**0.5


# ✅ 组合优于继承
class Engine:
    def start(self):
        pass


class Car:
    def __init__(self):
        self._engine = Engine()

    def start(self):
        self._engine.start()


# ✅ 使用__slots__优化内存（可选）
class OptimizedUser:
    __slots__ = ['name', 'email', 'age']

    def __init__(self, name: str, email: str, age: int):
        self.name = name
        self.email = email
        self.age = age
```

---

## 6. 异常处理

### 6.1 异常使用规范

```python
# ✅ 自定义异常
class ValidationError(Exception):
    """数据验证异常"""
    pass


class BusinessError(Exception):
    """业务逻辑异常"""

    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(message)


# ✅ 异常处理
def get_user_by_id(user_id: int) -> dict:
    try:
        user = database.query(f"SELECT * FROM users WHERE id = {user_id}")
        if not user:
            raise BusinessError("USER_NOT_FOUND", "用户不存在")
        return user
    except BusinessError:
        raise  # 重新抛出业务异常
    except Exception as e:
        logger.error(f"查询用户失败: {e}")
        raise BusinessError("DB_ERROR", "系统繁忙")


# ✅ 使用上下文管理器
with open('file.txt', 'r') as f:
    content = f.read()

# ✅ 资源清理
try:
    connection = db.get_connection()
    result = connection.execute(query)
except Exception as e:
    logger.error(e)
    raise
finally:
    if 'connection' in locals():
        connection.close()


# ✅ 异常链
try:
    process_data(data)
except ValueError as e:
    raise BusinessError("INVALID_DATA", "数据处理失败") from e
```

---

## 7. 常用代码模板

### 7.1 数据模型模板

```python
"""用户数据模型"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional
from enum import Enum


class UserStatus(Enum):
    """用户状态枚举"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    BANNED = "banned"


@dataclass
class User:
    """用户数据类"""
    id: int
    username: str
    email: str
    status: UserStatus = UserStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    tags: List[str] = field(default_factory=list)

    def __post_init__(self):
        """数据验证"""
        if not self.username or len(self.username) < 3:
            raise ValueError("用户名至少3个字符")
        if '@' not in self.email:
            raise ValueError("无效的邮箱格式")

    @property
    def is_active(self) -> bool:
        """判断是否激活"""
        return self.status == UserStatus.ACTIVE

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'tags': self.tags
        }


@dataclass
class UserRepository:
    """用户仓库类"""

    def __init__(self):
        self._users: List[User] = []

    def save(self, user: User) -> User:
        """保存用户"""
        existing = self.find_by_id(user.id)
        if existing:
            self._users = [u for u in self._users if u.id != user.id]
        self._users.append(user)
        return user

    def find_by_id(self, user_id: int) -> Optional[User]:
        """根据ID查找"""
        for user in self._users:
            if user.id == user_id:
                return user
        return None

    def find_by_username(self, username: str) -> Optional[User]:
        """根据用户名查找"""
        for user in self._users:
            if user.username == username:
                return user
        return None

    def find_all(self) -> List[User]:
        """获取所有用户"""
        return list(self._users)
```

### 7.2 服务层模板

```python
"""用户服务层"""
from typing import List, Optional
from dataclasses import dataclass

from models import User, UserStatus, UserRepository
from exceptions import BusinessError


@dataclass
class UserService:
    """用户服务类"""
    repository: UserRepository

    def create_user(self, username: str, email: str, password: str) -> User:
        """
        创建新用户

        Args:
            username: 用户名
            email: 邮箱
            password: 密码

        Returns:
            创建的用户对象

        Raises:
            BusinessError: 用户名或邮箱已存在
        """
        # 校验用户名唯一性
        if self.repository.find_by_username(username):
            raise BusinessError("USERNAME_EXISTS", "用户名已存在")

        # 校验邮箱格式（简化示例）
        if not self._validate_email(email):
            raise BusinessError("INVALID_EMAIL", "邮箱格式不正确")

        # 创建用户
        user = User(
            id=self._generate_id(),
            username=username,
            email=email,
            status=UserStatus.ACTIVE
        )

        return self.repository.save(user)

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """根据ID获取用户"""
        return self.repository.find_by_id(user_id)

    def get_active_users(self, limit: int = 10) -> List[User]:
        """获取活跃用户"""
        users = self.repository.find_all()
        return [u for u in users if u.is_active][:limit]

    def deactivate_user(self, user_id: int) -> User:
        """停用用户"""
        user = self.repository.find_by_id(user_id)
        if not user:
            raise BusinessError("USER_NOT_FOUND", "用户不存在")

        user.status = UserStatus.INACTIVE
        return self.repository.save(user)

    def _validate_email(self, email: str) -> bool:
        """验证邮箱格式"""
        import re
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return bool(re.match(pattern, email))

    def _generate_id(self) -> int:
        """生成ID"""
        return len(self.repository.find_all()) + 1
```

### 7.3 配置文件模板

```python
"""配置文件示例 - config.py"""

from pathlib import Path
from typing import Dict, Any
import json


class Config:
    """应用配置类"""

    # 基础配置
    DEBUG: bool = False
    TESTING: bool = False

    # 数据库配置
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_NAME: str = "myapp"
    DB_USER: str = "postgres"
    DB_PASSWORD: str = ""

    # API配置
    API_BASE_URL: str = "https://api.example.com"
    API_TIMEOUT: int = 30
    API_MAX_RETRIES: int = 3

    # 安全配置
    SECRET_KEY: str = "change-me-in-production"
    JWT_EXPIRATION_HOURS: int = 24
    PASSWORD_MIN_LENGTH: int = 8

    # 邮件配置
    SMTP_HOST: str = "smtp.example.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""

    @classmethod
    def from_json(cls, file_path: str) -> 'Config':
        """从JSON文件加载配置"""
        with open(file_path, 'r') as f:
            data = json.load(f)

        config = cls()
        for key, value in data.items():
            if hasattr(config, key.upper()):
                setattr(config, key.upper(), value)
        return config

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            key: getattr(self, key)
            for key in dir(self)
            if not key.startswith('_') and key.isupper()
        }


# 生产环境配置
class ProductionConfig(Config):
    DEBUG = False
    TESTING = False


# 开发环境配置
class DevelopmentConfig(Config):
    DEBUG = True
    DB_HOST = "localhost"
    DB_NAME = "myapp_dev"


# 测试环境配置
class TestConfig(Config):
    TESTING = True
    DB_NAME = "myapp_test"
```

---

## 8. 最佳实践清单

### ✅ 推荐做法
```
1. 遵循PEP 8编码规范
2. 使用类型注解提高代码可读性
3. 使用dataclass简化数据类
4. 优先使用列表/字典/集合推导式
5. 使用上下文管理器管理资源
6. 使用f-string格式化字符串
7. 使用logging模块记录日志
8. 使用pathlib处理文件路径
9. 使用枚举类管理常量
10. 使用partial简化函数调用
11. 使用itertools处理迭代
12. 合理使用装饰器
```

### ❌ 避免做法
```
1. 避免使用 from module import *
2. 避免硬编码魔法数字
3. 避免使用可变对象作为默认参数
4. 避免修改迭代中的序列
5. 避免捕获裸露的Exception
6. 避免使用+拼接字符串
7. 避免使用单字母变量名（循环除外）
8. 避免过深的嵌套（建议≤3层）
9. 避免在函数中返回不一致的类型
10. 避免使用全局变量
```
