# Go 编码规范
版本: 1.0 

## 1. 命名规范

### 1.1 包命名

```go
// ✅ 包名：小写、简短、不含下划线
package user          // 用户模块
package httpdemo     // http示例
package jsonutil     // json工具

// ❌ 错误示例
package User_Service
package mypackage

// ✅ 避免使用common、util、lib等通用名称
```

### 1.2 变量/函数命名

```go
// ============ 变量命名 ============

// ✅ 驼峰命名，首字母大写导出，小写不导出
type UserService struct{}
var maxCount int
var defaultTimeout = 5

// ✅ 简短命名用于局部变量
for i := 0; i < n; i++ {}
s := fmt.Sprintf("%s-%d", name, id)

// ✅ 有意义的命名
var userCount int
var totalPrice float64

// ============ 函数命名 ============

// ✅ 导出函数：PascalCase
func GetUserByID(id int) (*User, error) {}
func CalculateTotal(items []Item) float64 {}

// ✅ 非导出函数：camelCase
func validateEmail(email string) bool {}
func buildUserResponse(user *User) UserResponse {}

// ✅ 函数名体现返回值类型
func (u *User) IsActive() bool {}
func (u *User) GetName() string {}

// ✅ 错误处理函数名以 Err 结尾
func ErrNotFound(err error) error {}
func ErrInvalidInput(err error) error {}
```

### 1.3 常量/接口/错误命名

```go
// ============ 常量命名 ============

// ✅ 驼峰或全大写下划线分隔
const MaxRetryCount = 3
const max_retry_count = 3  // 也可接受

// ✅ 枚举类型分组
const (
    StatusPending   = "pending"
    StatusActive    = "active"
    StatusInactive  = "inactive"
)

// ✅ 使用 iota 创建枚举
type OrderStatus int
const (
    OrderStatusPending OrderStatus = iota
    OrderStatusPaid
    OrderStatusShipped
    OrderStatusCompleted
)

// ============ 接口命名 ============

// ✅ 接口名通常以 -er 结尾
type Reader interface {
    Read(p []byte) (n int, err error)
}

type Writer interface {
    Write(p []byte) (n int, err error)
}

type Logger interface {
    Info(msg string)
    Error(msg string)
}

// ✅ 单一方法接口
type Cache interface {
    Get(key string) (value interface{}, ok bool)
    Set(key string, value interface{})
}
```

---

## 2. 代码格式规范

### 2.1 缩进与空白

```go
// ✅ 缩进：4个空格（IDE自动处理）
// ✅ 左大括号同行
func main() {
    fmt.Println("Hello")
}

// ❌ 避免
func main()
{
    fmt.Println("Hello")
}

// ✅ 空行使用
func init() {
    // 初始化代码
}

// 空一行分隔逻辑
func process() {
    // 第一步
    result := stepOne()
    
    // 第二步
    result = stepTwo(result)
    
    // 第三步
    output(result)
}
```

### 2.2 导入语句

```go
// ✅ 导入分组：标准库 → 第三方 → 本地
import (
    // 标准库
    "encoding/json"
    "fmt"
    "io"
    "net/http"
    
    // 第三方库
    "github.com/spf13/cobra"
    "gorm.io/gorm"
    
    // 本地包
    "myproject/internal/model"
    "myproject/pkg/utils"
)

// ✅ 使用别名避免冲突
import (
    userModel "myproject/models/user"
    adminModel "myproject/models/admin"
)

// ✅ 使用 _ 导入只执行 init
import _ "github.com/lib/pq"
```

### 2.3 注释规范

```go
// ============ 包注释 ============

// Package user 提供用户相关的业务逻辑处理
// 包括用户注册、登录、信息管理等功能
package user

// ============ 函数注释 ============

// GetUserByID 根据用户ID获取用户信息
// 如果用户不存在返回 ErrUserNotFound
func GetUserByID(id int) (*User, error) {
    // ...
}

// ============ 方法注释 ============

// IsActive 判断用户是否处于激活状态
// 激活状态的用户可以正常登录和使用系统功能
func (u *User) IsActive() bool {
    return u.Status == StatusActive
}

// ============ 行内注释 ============

func main() {
    maxRetries := 3 // 最大重试次数
    timeout := 5    // 超时时间（秒）
}

// ============ TODO 注释 ============

// TODO: 优化查询性能
// TODO: 添加缓存支持
```

---

## 3. 类型与结构体

### 3.1 结构体定义

```go
// ============ 结构体命名 ============

// ✅ 名词或名词短语
type User struct {
    ID       int
    Name     string
    Email    string
    Status   UserStatus
}

// ✅ 私有字段
type user struct {
    id       int
    password string  // 密码不能导出
}

// ============ 结构体标签 ============

type User struct {
    ID       int    `json:"id" gorm:"primaryKey"`
    Name     string `json:"name" gorm:"size:50;not null"`
    Email    string `json:"email" gorm:"uniqueIndex"`
    Password string `json:"-" gorm:"size:255"`           // JSON序列化时忽略
    Age      int    `json:"age,omitempty"`              // 零值时忽略
}

// ============ 嵌套结构 ============

type Address struct {
    City    string
    Country string
}

type User struct {
    Name    string
    Address Address  // 匿名嵌套
}

type UserProfile struct {
    User   *User    // 命名嵌套
    Bio    string
}
```

### 3.2 接口设计

```go
// ============ 接口组合 ============

type ReadWriter interface {
    Reader
    Writer
}

// ============ 接口接收器 ============

// 值接收器
func (u User) IsActive() bool {
    return u.Status == StatusActive
}

// 指针接收器（如果需要修改对象）
func (u *User) SetStatus(status UserStatus) {
    u.Status = status
}

// ✅ 建议始终使用指针接收器保持一致性
func (u *User) GetID() int {
    return u.ID
}
```

---

## 4. 函数设计

### 4.1 函数规范

```go
// ✅ 明确返回错误
func GetUserByID(id int) (*User, error) {
    user, err := db.FindUser(id)
    if err != nil {
        return nil, fmt.Errorf("get user: %w", err)
    }
    return user, nil
}

// ✅ 多返回值
func ValidateEmail(email string) (bool, error) {
    if email == "" {
        return false, errors.New("email is required")
    }
    return strings.Contains(email, "@"), nil
}

// ✅ 变长参数
func Sum(numbers ...int) int {
    total := 0
    for _, n := range numbers {
        total += n
    }
    return total
}

// ✅ defer 清理资源
func processFile(path string) error {
    f, err := os.Open(path)
    if err != nil {
        return err
    }
    defer f.Close()
    
    // 处理文件
    return nil
}

// ✅ 上下文传播
func fetchData(ctx context.Context, id int) (*Data, error) {
    req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
    if err != nil {
        return nil, err
    }
    
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()
    
    return parseResponse(resp)
}
```

### 4.2 错误处理

```go
// ============ 错误定义 ============

// ✅ 使用 errors.New 创建简单错误
var ErrNotFound = errors.New("user not found")
var ErrInvalidInput = errors.New("invalid input")

// ✅ 使用 fmt.Errorf 添加上下文
func GetUser(id int) (*User, error) {
    user, err := db.Find(id)
    if err != nil {
        return nil, fmt.Errorf("get user %d: %w", id, err)
    }
    return user, nil
}

// ✅ 自定义错误类型
type ValidationError struct {
    Field   string
    Message string
}

func (e *ValidationError) Error() string {
    return fmt.Sprintf("%s: %s", e.Field, e.Message)
}

// ============ 错误检查 ============

// ✅ 使用 errors.Is 检查错误
if errors.Is(err, ErrNotFound) {
    // 处理未找到
}

// ✅ 使用 errors.As 断言错误类型
var validationErr *ValidationError
if errors.As(err, &validationErr) {
    fmt.Printf("验证失败: %s\n", validationErr.Message)
}
```

---

## 5. 常用代码模板

### 5.1 项目结构

```
myproject/
├── cmd/
│   └── server/
│       └── main.go
├── internal/
│   ├── handler/
│   │   └── user_handler.go
│   ├── service/
│   │   └── user_service.go
│   ├── repository/
│   │   └── user_repository.go
│   ├── model/
│   │   └── user.go
│   └── middleware/
│       └── auth.go
├── pkg/
│   ├── utils/
│   └── logger/
├── configs/
│   └── config.yaml
├── go.mod
└── go.sum
```

### 5.2 HTTP处理模板

```go
// ============ Handler 模板 ============

package handler

import (
    "encoding/json"
    "net/http"
    "strconv"
    
    "myproject/internal/service"
    "myproject/pkg/response"
)

type UserHandler struct {
    userService *service.UserService
}

func NewUserHandler(userService *service.UserService) *UserHandler {
    return &UserHandler{
        userService: userService,
    }
}

// GetUserByID 获取用户详情
// @Summary 获取用户详情
// @Param id path int true "用户ID"
// @Success 200 {object} model.User
// @Router /api/users/{id} [get]
func (h *UserHandler) GetUserByID(w http.ResponseWriter, r *http.Request) {
    idStr := r.PathValue("id")
    id, err := strconv.Atoi(idStr)
    if err != nil {
        response.Error(w, http.StatusBadRequest, "invalid user id")
        return
    }
    
    user, err := h.userService.GetUserByID(r.Context(), id)
    if err != nil {
        if err == service.ErrUserNotFound {
            response.Error(w, http.StatusNotFound, "user not found")
            return
        }
        response.Error(w, http.StatusInternalServerError, "internal error")
        return
    }
    
    response.Success(w, user)
}

// CreateUser 创建用户
// @Summary 创建用户
// @Accept json
// @Produce json
// @Param body body model.CreateUserRequest true "创建用户请求"
// @Success 201 {object} model.User
// @Router /api/users [post]
func (h *UserHandler) CreateUser(w http.ResponseWriter, r *http.Request) {
    var req model.CreateUserRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        response.Error(w, http.StatusBadRequest, "invalid request body")
        return
    }
    
    user, err := h.userService.CreateUser(r.Context(), &req)
    if err != nil {
        response.Error(w, http.StatusInternalServerError, err.Error())
        return
    }
    
    response.Success(w, http.StatusCreated, user)
}
```

### 5.3 Service模板

```go
// ============ Service 模板 ============

package service

import (
    "context"
    "errors"
    
    "myproject/internal/model"
    "myproject/internal/repository"
)

var (
    ErrUserNotFound   = errors.New("user not found")
    ErrInvalidInput   = errors.New("invalid input")
    ErrUserExists     = errors.New("user already exists")
)

type UserService struct {
    repo *repository.UserRepository
}

func NewUserService(repo *repository.UserRepository) *UserService {
    return &UserService{repo: repo}
}

// GetUserByID 根据ID获取用户
func (s *UserService) GetUserByID(ctx context.Context, id int) (*model.User, error) {
    if id <= 0 {
        return nil, ErrInvalidInput
    }
    
    user, err := s.repo.FindByID(ctx, id)
    if err != nil {
        return nil, err
    }
    if user == nil {
        return nil, ErrUserNotFound
    }
    
    return user, nil
}

// CreateUser 创建新用户
func (s *UserService) CreateUser(ctx context.Context, req *model.CreateUserRequest) (*model.User, error) {
    // 参数验证
    if err := validateCreateRequest(req); err != nil {
        return nil, err
    }
    
    // 检查用户是否存在
    existing, err := s.repo.FindByEmail(ctx, req.Email)
    if err != nil {
        return nil, err
    }
    if existing != nil {
        return nil, ErrUserExists
    }
    
    // 创建用户
    user := &model.User{
        Name:     req.Name,
        Email:    req.Email,
        Password: req.Password, // 实际应加密
        Status:   model.StatusActive,
    }
    
    if err := s.repo.Create(ctx, user); err != nil {
        return nil, err
    }
    
    return user, nil
}

func validateCreateRequest(req *model.CreateUserRequest) error {
    if req.Name == "" {
        return errors.New("name is required")
    }
    if req.Email == "" || !strings.Contains(req.Email, "@") {
        return errors.New("invalid email")
    }
    if len(req.Password) < 6 {
        return errors.New("password must be at least 6 characters")
    }
    return nil
}
```

---

## 6. 最佳实践清单

### ✅ 推荐做法
```
1. 使用 gofmt/golint 格式化代码
2. 错误作为最后一个返回值
3. 使用 context.Context 传递请求上下文
4. 使用 defer 关闭资源
5. 结构体标签使用反引号
6. 接口设计：小、具体、单一职责
7. 使用 errors.Is/As 检查错误
8. 使用 init 函数初始化模块
9. 变量声明靠近使用位置
10. 使用 slice、map、chan 作为引用类型
```

### ❌ 避免做法
```
1. 避免使用 panic 处理正常错误
2. 避免忽略错误返回值 _
3. 避免使用 nil slice（用空 slice 替代）
4. 避免在循环中使用 defer
5. 避免使用 time.After 处理超时
6. 避免使用 gin.H{} 等 Map 结构
7. 避免导出未使用的类型或函数
8. 避免在接口中包含不必要的方法
9. 避免使用 len(channel) > 0 猜测性检查
10. 避免使用 reflect 或 unsafe 包
```

