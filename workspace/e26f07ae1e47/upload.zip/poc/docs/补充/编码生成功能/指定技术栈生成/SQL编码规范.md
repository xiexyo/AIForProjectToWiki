# SQL 编码规范
版本: 1.0 

## 1. 命名规范

### 1.1 数据库对象命名

| 对象类型       | 命名风格     | 命名示例                    |
|----------------|--------------|-----------------------------|
| 数据库         | PascalCase   | InventoryManagement         |
| 表             | PascalCase/复数 | Users, OrderItems, Products |
| 视图           | v_前缀 PascalCase | v_ActiveUsers, v_MonthlySales |
| 存储过程       | sp_前缀 PascalCase | sp_InsertOrder, sp_GetUserById |
| 函数           | fn_前缀 PascalCase | fn_CalculateTotal, fn_GetAge |
| 触发器         | tr_前缀 表名_操作 | tr_Users_AfterInsert        |
| 主键约束       | pk_表名      | pk_Users                    |
| 外键约束       | fk_表名_引用表 | fk_Orders_Users             |
| 唯一约束       | uq_表名_列名  | uq_Users_Email              |
| 索引           | ix_表名_列名  | ix_Orders_UserId, ix_Orders_Date |
| 序列           | seq_表名     | seq_Users, seq_Orders       |

### 1.2 字段命名

| 类型               | 命名风格    | 命名示例                    |
|--------------------|-------------|-----------------------------|
| 普通字段           | snake_case  | user_name, create_time      |
| 主键字段           | id 或 表名_id | id, user_id, order_id      |
| 外键字段           | 表名_id     | user_id, product_id         |
| 时间戳字段         | _time 后缀  | create_time, update_time    |
| 布尔字段           | is_/has_前缀 | is_active, has_permission   |
| 数量/金额字段      | _count/_amount后缀 | order_count, total_amount |
| 状态字段           | _status 后缀 | order_status, user_status |

### 1.3 命名示例

```sql
-- ✅ 正确示例

-- 表命名（使用复数或业务名称）
CREATE TABLE users (
    id              BIGINT PRIMARY KEY,
    user_name       VARCHAR(50) NOT NULL,
    email           VARCHAR(100) NOT NULL,
    phone_number    VARCHAR(20),
    is_active       BOOLEAN DEFAULT TRUE,
    create_time     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time     TIMESTAMP
);

-- 索引命名
CREATE INDEX ix_users_email ON users(email);
CREATE INDEX ix_users_create_time ON users(create_time);

-- 外键命名
ALTER TABLE orders ADD CONSTRAINT fk_orders_users 
    FOREIGN KEY (user_id) REFERENCES users(id);

-- 视图命名
CREATE VIEW v_active_users AS
SELECT * FROM users WHERE is_active = TRUE;

-- 存储过程命名
CREATE PROCEDURE sp_get_user_orders(
    IN p_user_id BIGINT,
    OUT p_order_count INT
)
BEGIN
    -- 存储过程内容
END;


-- ❌ 错误示例

-- 表名单复数混用
CREATE TABLE user_info;  -- 应为 users
CREATE TABLE orders_table;  -- 应为 orders

-- 字段名使用保留字
CREATE TABLE test (
    select VARCHAR(50),  -- 使用了保留字
    from INT,  -- 使用了保留字
    index VARCHAR(50)  -- 使用了保留字
);

-- 命名过长或过短
CREATE TABLE t;  -- 命名过短
CREATE TABLE user_information_detail_table;  -- 命名过长

-- 命名不统一
CREATE TABLE user_orders;
CREATE TABLE UserAddresses;  -- 命名风格不一致
CREATE TABLE order_items;  -- 下划线风格与其他不一致
```

---

## 2. SQL书写规范

### 2.1 关键字大写

```sql
-- ✅ 关键字大写
SELECT 
    user_id,
    user_name,
    email
FROM 
    users
WHERE 
    is_active = TRUE
    AND create_time >= '2024-01-01'
ORDER BY 
    create_time DESC;


-- ❌ 关键字小写
select 
    user_id,
    user_name 
from users 
where is_active = true;


-- 常见关键字
SELECT, FROM, WHERE, AND, OR, NOT, IN, LIKE, BETWEEN,
INSERT, UPDATE, DELETE, CREATE, ALTER, DROP, TRUNCATE,
JOIN, LEFT, RIGHT, INNER, OUTER, ON, USING,
GROUP BY, HAVING, ORDER BY, DISTINCT, LIMIT, OFFSET,
AS, UNION, INTERSECT, EXCEPT, CASE, WHEN, THEN, ELSE, END,
NULL, NOT NULL, PRIMARY KEY, FOREIGN KEY, REFERENCES, CONSTRAINT,
INDEX, VIEW, PROCEDURE, FUNCTION, TRIGGER, IF, EXISTS, COUNT, SUM, AVG, MAX, MIN
```

### 2.2 缩进与格式

```sql
-- ✅ 推荐格式
SELECT 
    u.user_id,
    u.user_name,
    u.email,
    COUNT(o.order_id) AS order_count,
    SUM(o.total_amount) AS total_spent
FROM 
    users u
LEFT JOIN 
    orders o ON u.user_id = o.user_id
WHERE 
    u.is_active = TRUE
    AND u.create_time >= '2024-01-01'
GROUP BY 
    u.user_id,
    u.user_name,
    u.email
HAVING 
    COUNT(o.order_id) > 5
ORDER BY 
    total_spent DESC,
    u.user_name ASC
LIMIT 100;


-- ✅ INSERT语句格式
INSERT INTO users (
    user_name,
    email,
    phone_number,
    is_active,
    create_time
) VALUES (
    '张三',
    'zhangsan@example.com',
    '13800138000',
    TRUE,
    CURRENT_TIMESTAMP
);


-- ✅ UPDATE语句格式
UPDATE 
    users
SET 
    email = 'new_email@example.com',
    update_time = CURRENT_TIMESTAMP
WHERE 
    user_id = 12345
    AND is_active = TRUE;


-- ✅ CASE语句格式
SELECT 
    user_name,
    order_count,
    CASE 
        WHEN order_count = 0 THEN '新用户'
        WHEN order_count < 5 THEN '普通用户'
        WHEN order_count < 20 THEN '活跃用户'
        ELSE 'VIP用户'
    END AS user_level
FROM (
    SELECT 
        u.user_name,
        COUNT(o.order_id) AS order_count
    FROM 
        users u
    LEFT JOIN 
        orders o ON u.user_id = o.user_id
    GROUP BY 
        u.user_id,
        u.user_name
) AS user_stats;
```

### 2.3 别名使用

```sql
-- ✅ 使用别名提高可读性
SELECT 
    u.user_id AS user_id,
    u.user_name AS user_name,
    o.order_id AS order_id,
    o.total_amount AS order_amount
FROM 
    users u
INNER JOIN 
    orders o ON u.user_id = o.user_id
WHERE 
    u.is_active = TRUE;


-- ✅ 清晰的自连接示例
SELECT 
    e.employee_name AS employee,
    m.employee_name AS manager
FROM 
    employees e
LEFT JOIN 
    employees m ON e.manager_id = m.employee_id;


-- ❌ 避免无意义的别名
SELECT 
    u.user_id,
    u.user_name,
    o.order_id
FROM 
    users u,  -- u这种单字母别名没有意义
    orders o
WHERE 
    u.user_id = o.user_id;
```

---

## 3. 查询优化规范

### 3.1 SELECT字段规范

```sql
-- ✅ 明确指定需要的字段
SELECT 
    user_id,
    user_name,
    email
FROM 
    users;


-- ❌ 避免使用 SELECT *
SELECT 
    *
FROM 
    users;


-- ✅ 需要所有字段时才用 *
SELECT 
    u.*,
    o.order_count
FROM 
    users u
LEFT JOIN (
    SELECT 
        user_id,
        COUNT(*) AS order_count
    FROM 
        orders
    GROUP BY 
        user_id
) o ON u.user_id = o.user_id;
```

### 3.2 WHERE子句规范

```sql
-- ✅ 使用参数化查询防止SQL注入
-- Java
String sql = "SELECT * FROM users WHERE user_id = ?";
PreparedStatement ps = connection.prepareStatement(sql);
ps.setLong(1, userId);

-- Python
cursor.execute("SELECT * FROM users WHERE user_id = %s", (user_id,))

-- ✅ LIKE查询优化
-- 前缀匹配可以使用索引
SELECT * FROM users WHERE email LIKE 'zhang%';

-- ❌ 前缀通配符无法使用索引
SELECT * FROM users WHERE email LIKE '%@example.com';


-- ✅ 使用EXISTS替代IN（子查询较大时）
SELECT 
    user_name
FROM 
    users u
WHERE EXISTS (
    SELECT 
        1
    FROM 
        orders o
    WHERE 
        o.user_id = u.user_id
        AND o.create_time >= '2024-01-01'
);

-- ✅ 使用JOIN替代子查询
SELECT 
    u.user_name,
    o.order_count
FROM 
    users u
INNER JOIN (
    SELECT 
        user_id,
        COUNT(*) AS order_count
    FROM 
        orders
    GROUP BY 
        user_id
) o ON u.user_id = o.user_id;
```

### 3.3 索引使用规范

```sql
-- ✅ 创建适当的索引
-- 单列索引
CREATE INDEX ix_users_email ON users(email);
CREATE INDEX ix_users_phone ON users(phone_number);

-- 复合索引（考虑查询顺序）
CREATE INDEX ix_orders_user_date ON orders(user_id, create_time DESC);

-- 唯一索引
CREATE UNIQUE INDEX uq_users_email ON users(email);


-- ✅ 复合索引遵循最左前缀原则
-- 索引 idx_orders_user_date 支持：
-- WHERE user_id = ?
-- WHERE user_id = ? AND create_time >= ?
-- WHERE user_id = ? AND create_time BETWEEN ? AND ?

-- ❌ 无法使用索引的情况
-- WHERE create_time >= ?
-- WHERE create_time >= ? AND user_id = ?  -- 顺序不对
```

---

## 4. 表设计规范

### 4.1 表创建规范

```sql
-- ✅ 完整的表创建语句
CREATE TABLE users (
    -- 主键
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- 用户信息
    user_name       VARCHAR(50) NOT NULL COMMENT '用户名',
    password_hash   VARCHAR(255) NOT NULL COMMENT '密码哈希',
    email           VARCHAR(100) NOT NULL COMMENT '邮箱',
    phone_number    VARCHAR(20) COMMENT '手机号',
    
    -- 状态与时间
    is_active       BOOLEAN DEFAULT TRUE COMMENT '是否激活',
    create_time     TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    delete_time     TIMESTAMP NULL COMMENT '删除时间',
    
    -- 约束
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_phone (phone_number),
    INDEX ix_users_create_time (create_time),
    INDEX ix_users_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';


-- ✅ 外键设计
CREATE TABLE orders (
    order_id        BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id         BIGINT NOT NULL COMMENT '用户ID',
    order_no        VARCHAR(32) NOT NULL COMMENT '订单号',
    total_amount    DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '订单总额',
    order_status    TINYINT DEFAULT 1 COMMENT '订单状态',
    create_time     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT pk_orders PRIMARY KEY (order_id),
    CONSTRAINT uq_orders_no UNIQUE (order_no),
    CONSTRAINT fk_orders_users FOREIGN KEY (user_id) 
        REFERENCES users(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    INDEX ix_orders_user_id (user_id),
    INDEX ix_orders_status (order_status),
    INDEX ix_orders_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';
```

### 4.2 字段类型选择

```sql
-- ✅ 主键使用BIGINT
id BIGINT PRIMARY KEY AUTO_INCREMENT

-- ✅ 金额使用DECIMAL（精确计算）
total_amount DECIMAL(10,2)  -- 最大99999999.99

-- ❌ 避免使用FLOAT/DOUBLE做金额
total_amount FLOAT  -- 精度问题

-- ✅ 状态使用TINYINT或ENUM
order_status TINYINT DEFAULT 1  -- 1:待支付 2:已支付 3:已发货 4:已完成 5:已取消
-- 或
order_status ENUM('pending', 'paid', 'shipped', 'completed', 'cancelled')

-- ✅ 时间使用TIMESTAMP或DATETIME
create_time DATETIME NOT NULL
update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

-- ✅ 手机号使用VARCHAR
phone_number VARCHAR(20)

-- ✅ 固定长度使用CHAR
country_code CHAR(2)  -- 国家代码：CN, US, JP

-- ✅ 长文本使用TEXT
description TEXT
content TEXT
```

---

## 5. 常用SQL模板

### 5.1 分页查询模板

```sql
-- MySQL分页
SELECT 
    user_id,
    user_name,
    email,
    create_time
FROM 
    users
WHERE 
    is_active = TRUE
    AND create_time >= '2024-01-01'
ORDER BY 
    create_time DESC
LIMIT 20 OFFSET 0;


-- PostgreSQL分页
SELECT 
    user_id,
    user_name,
    email
FROM 
    users
WHERE 
    is_active = TRUE
ORDER BY 
    create_time DESC
LIMIT 20 OFFSET 0;


-- 通用分页存储过程
DELIMITER //

CREATE PROCEDURE sp_get_users_by_page(
    IN p_page_index INT,
    IN p_page_size INT,
    OUT p_total_count INT,
    OUT p_total_pages INT
)
BEGIN
    -- 计算总数
    SELECT COUNT(*) INTO p_total_count
    FROM users
    WHERE is_active = TRUE;
    
    SET p_total_pages = CEIL(p_total_count / p_page_size);
    
    -- 分页查询
    SELECT 
        user_id,
        user_name,
        email,
        create_time
    FROM 
        users
    WHERE 
        is_active = TRUE
    ORDER BY 
        create_time DESC
    LIMIT p_page_size OFFSET (p_page_index - 1) * p_page_size;
END //

DELIMITER ;
```

### 5.2 通用查询模板

```sql
-- 查询单条记录
SELECT 
    user_id,
    user_name,
    email
FROM 
    users
WHERE 
    user_id = ?
LIMIT 1;


-- 统计查询
SELECT 
    COUNT(*) AS total_count,
    COUNT(DISTINCT user_id) AS unique_users,
    SUM(total_amount) AS total_amount,
    AVG(total_amount) AS avg_amount,
    MAX(total_amount) AS max_amount,
    MIN(total_amount) AS min_amount
FROM 
    orders
WHERE 
    create_time >= ?;


-- 日期统计
SELECT 
    DATE(create_time) AS order_date,
    COUNT(*) AS order_count,
    SUM(total_amount) AS daily_amount
FROM 
    orders
WHERE 
    create_time >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY 
    DATE(create_time)
ORDER BY 
    order_date DESC;


-- 关联查询
SELECT 
    u.user_id,
    u.user_name,
    u.email,
    COUNT(o.order_id) AS order_count,
    COALESCE(SUM(o.total_amount), 0) AS total_spent
FROM 
    users u
LEFT JOIN 
    orders o ON u.user_id = o.user_id
WHERE 
    u.is_active = TRUE
GROUP BY 
    u.user_id,
    u.user_name,
    u.email
ORDER BY 
    total_spent DESC
LIMIT 100;
```

### 5.3 增删改模板

```sql
-- 插入单条
INSERT INTO users (
    user_name,
    email,
    password_hash,
    phone_number,
    is_active
) VALUES (
    '张三',
    'zhangsan@example.com',
    'hashed_password',
    '13800138000',
    TRUE
);

-- 插入多条
INSERT INTO users (
    user_name,
    email,
    password_hash
) VALUES 
    ('用户1', 'user1@example.com', 'hash1'),
    ('用户2', 'user2@example.com', 'hash2'),
    ('用户3', 'user3@example.com', 'hash3');

-- 插入或更新（MySQL）
INSERT INTO user_stats (
    user_id,
    login_count,
    last_login_time
) VALUES (
    12345,
    1,
    CURRENT_TIMESTAMP
) ON DUPLICATE KEY UPDATE 
    login_count = login_count + 1,
    last_login_time = CURRENT_TIMESTAMP;


-- 更新
UPDATE 
    users
SET 
    email = 'new_email@example.com',
    phone_number = '13900139000',
    update_time = CURRENT_TIMESTAMP
WHERE 
    user_id = 12345
    AND is_active = TRUE;


-- 软删除
UPDATE 
    users
SET 
    is_active = FALSE,
    delete_time = CURRENT_TIMESTAMP
WHERE 
    user_id = 12345;


-- 批量更新
UPDATE 
    orders
SET 
    order_status = 5,  -- 已取消
    update_time = CURRENT_TIMESTAMP
WHERE 
    order_status = 1  -- 待支付
    AND create_time < DATE_SUB(NOW(), INTERVAL 7 DAY);  -- 创建超过7天


-- 删除（谨慎使用）
DELETE FROM 
    orders
WHERE 
    order_id = 12345
    AND order_status = 5;  -- 只删除已取消的订单
```

---

## 6. 最佳实践清单

### ✅ 推荐做法
```
1. 使用自增ID或UUID作为主键
2. 为高频查询字段创建索引
3. 使用事务确保数据一致性
4. 使用参数化查询防止SQL注入
5. 避免在WHERE子句中对字段使用函数
6. 使用EXPLAIN分析查询计划
7. 批量操作使用事务包裹
8. 敏感数据加密存储
9. 定期清理测试数据
10. 使用软删除保留数据
```

### ❌ 避免做法
```
1. 避免使用SELECT *
2. 避免在循环中执行SQL
3. 避免在数据库层做复杂计算
4. 避免存储大文件（使用对象存储）
5. 避免使用动态SQL拼接
6. 避免大量使用触发器
7. 避免使用存储过程做业务逻辑
8. 避免字段默认值使用NOW()等函数
9. 避免不建索引就上线
10. 避免删除表时不使用备份
```

---

## 7. 常见问题优化

```sql
-- ❌ 慢查询：全表扫描
SELECT * FROM orders WHERE YEAR(create_time) = 2024;

-- ✅ 优化：使用范围查询
SELECT * FROM orders WHERE create_time >= '2024-01-01' AND create_time < '2025-01-01';


-- ❌ 慢查询：前导通配符
SELECT * FROM users WHERE email LIKE '%@example.com';

-- ✅ 优化：考虑全文索引或反向存储
ALTER TABLE users ADD COLUMN email_domain VARCHAR(100);
UPDATE users SET email_domain = SUBSTRING_INDEX(email, '@', -1);


-- ❌ 慢查询：OR条件
SELECT * FROM orders WHERE user_id = 1 OR status = 'pending';

-- ✅ 优化：使用UNION
SELECT * FROM orders WHERE user_id = 1
UNION ALL
SELECT * FROM orders WHERE status = 'pending' AND user_id != 1;


-- ❌ 慢查询：IN子句过多
SELECT * FROM orders WHERE user_id IN (1,2,3,4,5,...,10000);

-- ✅ 优化：使用JOIN或分批查询
SELECT * FROM orders o
INNER JOIN (SELECT 1 UNION SELECT 2 ...) t ON o.user_id = t.id;
```


